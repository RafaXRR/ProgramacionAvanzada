package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import persistencia.ProductoPersistencia;
import persistencia.VentaPersistencia;

import util.ErrorControlador;
import vista.AlmacenVista;
import vista.BajoStockVista;
import vista.CorteCajaVista;
import vista.DevolucionesVista;
import vista.HistorialVentasVista;
import vista.MainVista;
import vista.ProductosVista;
import vista.ReportesVista;
import vista.VentasVista;

public class MainControlador
    implements ActionListener {

    private MainVista vista;

    private ProductoPersistencia
        productoPersistencia;

    private VentaPersistencia
        ventaPersistencia;

    public MainControlador(
        MainVista vista
    ) {

        this.vista = vista;

        productoPersistencia =
            new ProductoPersistencia();

        ventaPersistencia =
            new VentaPersistencia();

        cargarDashboard();

        this.vista
            .getBtnInicio()
            .addActionListener(this);

        this.vista
            .getBtnProductos()
            .addActionListener(this);

        this.vista
            .getBtnVentas()
            .addActionListener(this);

        this.vista
            .getBtnHistorial()
            .addActionListener(this);

        this.vista
            .getBtnAlmacen()
            .addActionListener(this);

        this.vista
            .getBtnReportes()
            .addActionListener(this);

        this.vista
            .getBtnDevoluciones()
            .addActionListener(this);

        this.vista
            .getBtnBajoStock()
            .addActionListener(this);

        this.vista
            .getBtnCorteCaja()
            .addActionListener(this);
    }

    public void cargarDashboard() {

        int productos =
            productoPersistencia
            .totalProductos();

        int ventas =
            ventaPersistencia
            .totalVentas();

        double ingresos =
            ventaPersistencia
            .obtenerIngresosTotales();

        int bajoStock =
            productoPersistencia
            .totalProductosBajoStock();

        vista
            .getLblTotalProductos()
            .setText(
                String.valueOf(productos)
            );

        vista
            .getLblTotalVentas()
            .setText(
                String.valueOf(ventas)
            );

        vista
            .getLblIngresos()
            .setText(
                String.format(
                    "$%.2f",
                    ingresos
                )
            );

        vista
            .getLblBajoStock()
            .setText(
                String.valueOf(bajoStock)
            );
    }

    @Override
    public void actionPerformed(
        ActionEvent e
    ) {

        if(
            e.getSource()
            ==
            vista.getBtnInicio()
        ) {

            vista.mostrarDashboard();

            cargarDashboard();
        }

        if(
            e.getSource()
            ==
            vista.getBtnProductos()
        ) {

            ProductosVista productos =
                new ProductosVista();

            new ProductoControlador(productos);

            vista.cargarModulo(productos);

            cargarDashboard();
        }

        if(
            e.getSource()
            ==
            vista.getBtnVentas()
        ) {

            VentasVista ventas =
                new VentasVista();

            new VentaControlador(ventas);

            vista.cargarModulo(ventas);

            cargarDashboard();
        }

        if(
            e.getSource()
            ==
            vista.getBtnHistorial()
        ) {

            HistorialVentasVista historial =
                new HistorialVentasVista();

            new HistorialVentasControlador(
                historial
            );

            vista.cargarModulo(historial);
        }

        if(
            e.getSource()
            ==
            vista.getBtnAlmacen()
        ) {

            AlmacenVista almacen =
                new AlmacenVista();

            new AlmacenControlador(almacen);

            vista.cargarModulo(almacen);

            cargarDashboard();
        }

        if(
            e.getSource()
            ==
            vista.getBtnReportes()
        ) {

            ReportesVista reportes =
                new ReportesVista();

            new ReportesControlador(reportes);

            vista.cargarModulo(reportes);
        }

        if(
            e.getSource()
            ==
            vista.getBtnDevoluciones()
        ) {

            DevolucionesVista devoluciones =
                new DevolucionesVista();

            new DevolucionesControlador(
                devoluciones
            );

            vista.cargarModulo(devoluciones);

            cargarDashboard();
        }

        if(
            e.getSource()
            ==
            vista.getBtnBajoStock()
        ) {

            int total =
                productoPersistencia
                .totalProductosBajoStock();

            if(total == 0) {

                ErrorControlador.mostrarExito(
                    "¡Todos los productos "
                    + "tienen stock suficiente!"
                );

                return;
            }

            BajoStockVista bajoStock =
                new BajoStockVista();

            new BajoStockControlador(bajoStock);

            vista.cargarModulo(bajoStock);
        }

        if(
            e.getSource()
            ==
            vista.getBtnCorteCaja()
        ) {

            CorteCajaVista corteCaja =
                new CorteCajaVista();

            new CorteCajaControlador(corteCaja);

            vista.cargarModulo(corteCaja);

            cargarDashboard();
        }
    }
}