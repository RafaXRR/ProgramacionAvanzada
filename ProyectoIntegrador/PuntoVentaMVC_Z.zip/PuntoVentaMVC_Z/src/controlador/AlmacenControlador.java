package controlador;

import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

import persistencia.ProductoPersistencia;
import util.ErrorControlador;
import vista.AlmacenVista;

public class AlmacenControlador
    implements ActionListener {

    private AlmacenVista vista;

    private ProductoPersistencia persistencia;

    private int idSeleccionado = -1;

    public AlmacenControlador(
        AlmacenVista vista
    ) {

        this.vista = vista;

        persistencia =
            new ProductoPersistencia();

        cargarTabla();

        this.vista
            .getBtnAgregarStock()
            .addActionListener(this);

        this.vista
            .getBtnQuitarStock()
            .addActionListener(this);

        this.vista
            .getBtnActualizarPrecio()
            .addActionListener(this);

        this.vista
            .getTablaProductos()
            .addMouseListener(
                new MouseAdapter() {

                    @Override
                    public void mouseClicked(
                        MouseEvent e
                    ) {

                        seleccionarProducto();
                    }
                }
            );
    }

    @Override
    public void actionPerformed(
        ActionEvent e
    ) {

        if(
            e.getSource()
            ==
            vista.getBtnAgregarStock()
        ) {

            moverStock(true);
        }

        if(
            e.getSource()
            ==
            vista.getBtnQuitarStock()
        ) {

            moverStock(false);
        }

        if(
            e.getSource()
            ==
            vista.getBtnActualizarPrecio()
        ) {

            actualizarPrecio();
        }
    }

    public void moverStock(
        boolean agregar
    ) {

        try {

            String txtId =
                vista
                .getTxtIdProducto()
                .getText()
                .trim();

            String txtCant =
                vista
                .getTxtCantidad()
                .getText()
                .trim();

            if(
                txtId.isEmpty()
                || txtCant.isEmpty()
            ) {

                ErrorControlador
                    .mostrarAdvertencia(
                        "Ingresa ID de producto "
                        + "y cantidad"
                    );

                return;
            }

            int id = Integer.parseInt(txtId);

            int cantidad =
                Integer.parseInt(txtCant);

            if(cantidad <= 0) {

                ErrorControlador
                    .mostrarAdvertencia(
                        "La cantidad debe ser "
                        + "mayor a cero"
                    );

                return;
            }

            boolean ok;

            String accion;

            if(agregar) {

                ok =
                    persistencia
                    .agregarStock(id, cantidad);

                accion = "agregado";

            } else {

                ok =
                    persistencia
                    .descontarStock(id, cantidad);

                accion = "descontado";
            }

            if(ok) {

                ErrorControlador.mostrarExito(
                    "Stock " + accion
                    + " correctamente"
                );

                limpiarCamposStock();

                cargarTabla();

            } else {

                ErrorControlador.mostrarError(
                    "Error al modificar stock",
                    null
                );
            }

        } catch (NumberFormatException ex) {

            ErrorControlador.mostrarAdvertencia(
                "Ingresa valores numéricos válidos"
            );

        } catch (Exception ex) {

            ErrorControlador.mostrarError(
                "Error inesperado",
                ex
            );
        }
    }

    public void actualizarPrecio() {

        try {

            int fila =
                vista
                .getTablaProductos()
                .getSelectedRow();

            if(fila == -1) {

                ErrorControlador
                    .mostrarAdvertencia(
                        "Selecciona un producto "
                        + "de la tabla"
                    );

                return;
            }

            int id = Integer.parseInt(
                vista
                .getTablaProductos()
                .getValueAt(fila, 0)
                .toString()
            );

            String txtPrecio =
                vista
                .getTxtNuevoPrecio()
                .getText()
                .trim();

            if(txtPrecio.isEmpty()) {

                ErrorControlador
                    .mostrarAdvertencia(
                        "Ingresa el nuevo precio"
                    );

                return;
            }

            double nuevoPrecio =
                Double.parseDouble(txtPrecio);

            if(nuevoPrecio <= 0) {

                ErrorControlador
                    .mostrarAdvertencia(
                        "El precio debe ser "
                        + "mayor a cero"
                    );

                return;
            }

            boolean ok =
                persistencia
                .actualizarPrecio(
                    id,
                    nuevoPrecio
                );

            if(ok) {

                ErrorControlador.mostrarExito(
                    "Precio actualizado a $"
                    + String.format(
                        "%.2f",
                        nuevoPrecio
                    )
                );

                vista
                    .getTxtNuevoPrecio()
                    .setText("");

                cargarTabla();

            } else {

                ErrorControlador.mostrarError(
                    "Error al actualizar precio",
                    null
                );
            }

        } catch (NumberFormatException ex) {

            ErrorControlador.mostrarAdvertencia(
                "Ingresa un precio numérico válido"
            );

        } catch (Exception ex) {

            ErrorControlador.mostrarError(
                "Error inesperado",
                ex
            );
        }
    }

    public void seleccionarProducto() {

        int fila =
            vista
            .getTablaProductos()
            .getSelectedRow();

        if(fila == -1) return;

        idSeleccionado =
            Integer.parseInt(
                vista
                .getTablaProductos()
                .getModel()
                .getValueAt(fila, 0)
                .toString()
            );

        vista
            .getTxtIdProducto()
            .setText(
                String.valueOf(
                    idSeleccionado
                )
            );

        String nombre =
            vista
            .getTablaProductos()
            .getModel()
            .getValueAt(fila, 1)
            .toString();

        Object rutaObj =
            vista
            .getTablaProductos()
            .getModel()
            .getValueAt(fila, 6);

        String ruta =
            rutaObj != null
            ? rutaObj.toString().trim()
            : "";

        vista
            .getLblNombreProducto()
            .setText(nombre);

        if(!ruta.isEmpty()) {

            try {

                Image img;

                if(
                    ruta.startsWith("http://")
                    || ruta.startsWith("https://")
                ) {

                    URL url = new URL(ruta);
                    img = ImageIO.read(url);

                } else {

                    ruta = ruta.replace("\\", "/");

                    File archivo = new File(ruta);

                    if(!archivo.exists()) {

                        vista
                            .getLblImagenProducto()
                            .setIcon(null);

                        vista
                            .getLblImagenProducto()
                            .setText("Imagen no encontrada");

                        return;
                    }

                    img = new ImageIcon(
                        archivo.getAbsolutePath()
                    ).getImage();

                    MediaTracker tracker =
                        new MediaTracker(vista);

                    tracker.addImage(img, 0);

                    try {
                        tracker.waitForAll();
                    } catch (InterruptedException ex2) {}
                }

                if(img != null) {

                    ImageIcon icono =
                        new ImageIcon(
                            img.getScaledInstance(
                                165,
                                120,
                                Image.SCALE_SMOOTH
                            )
                        );

                    vista
                        .getLblImagenProducto()
                        .setIcon(icono);

                    vista
                        .getLblImagenProducto()
                        .setText("");

                    vista
                        .getLblImagenProducto()
                        .revalidate();

                    vista
                        .getLblImagenProducto()
                        .repaint();

                } else {

                    vista
                        .getLblImagenProducto()
                        .setIcon(null);

                    vista
                        .getLblImagenProducto()
                        .setText("Imagen no disponible");
                }

            } catch(Exception ex) {

                vista
                    .getLblImagenProducto()
                    .setIcon(null);

                vista
                    .getLblImagenProducto()
                    .setText("Error: " + ex.getMessage());
            }

        } else {

            vista
                .getLblImagenProducto()
                .setIcon(null);

            vista
                .getLblImagenProducto()
                .setText("Sin imagen");
        }
    }

    public void limpiarCamposStock() {

        vista
            .getTxtIdProducto()
            .setText("");

        vista
            .getTxtCantidad()
            .setText("");
    }

    public void cargarTabla() {

        vista
            .getTablaProductos()
            .setModel(
                persistencia
                .listarProductos()
            );

        if(
            vista
            .getTablaProductos()
            .getColumnModel()
            .getColumnCount() > 6
        ) {

            vista
                .getTablaProductos()
                .getColumnModel()
                .removeColumn(
                    vista
                    .getTablaProductos()
                    .getColumnModel()
                    .getColumn(6)
                );
        }
    }
}