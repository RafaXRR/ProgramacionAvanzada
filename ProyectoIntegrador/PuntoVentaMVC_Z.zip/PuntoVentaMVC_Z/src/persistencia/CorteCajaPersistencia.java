package persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.table.DefaultTableModel;

import util.ErrorControlador;

public class CorteCajaPersistencia {

    public int abrirCorte(
        double fondoInicial
    ) {

        try {

            Connection conexion =
                Conexion.conectar();

            String sql =
                "INSERT INTO cortes_caja("
                + "fondo_inicial, estado"
                + ") VALUES(?, 'ABIERTO')";

            PreparedStatement statement =
                conexion.prepareStatement(
                    sql,
                    PreparedStatement
                    .RETURN_GENERATED_KEYS
                );

            statement.setDouble(
                1, fondoInicial
            );

            statement.executeUpdate();

            ResultSet resultado =
                statement.getGeneratedKeys();

            if(resultado.next()) {

                int id =
                    resultado.getInt(1);

                conexion.close();

                return id;
            }

            conexion.close();

            return -1;

        } catch (Exception e) {

            ErrorControlador.registrarEnLog(
                "Error al abrir corte",
                e
            );

            return -1;
        }
    }

    public boolean cerrarCorte(
        int idCorte,
        double totalEfectivo,
        String observaciones
    ) {

        try {

            // Calcular ventas del periodo
            Connection conexion =
                Conexion.conectar();

            String sqlVentas =
                "SELECT "
                + "COUNT(*) AS num_ventas, "
                + "ISNULL(SUM(monto_pagar), 0) "
                + "AS total_ventas "
                + "FROM ventas "
                + "WHERE CAST(fecha AS DATE) "
                + "= CAST(GETDATE() AS DATE)";

            PreparedStatement stVentas =
                conexion.prepareStatement(
                    sqlVentas
                );

            ResultSet rsVentas =
                stVentas.executeQuery();

            int numVentas = 0;

            double totalVentas = 0;

            if(rsVentas.next()) {

                numVentas =
                    rsVentas.getInt("num_ventas");

                totalVentas =
                    rsVentas.getDouble(
                        "total_ventas"
                    );
            }

            // Obtener fondo inicial
            String sqlFondo =
                "SELECT fondo_inicial "
                + "FROM cortes_caja "
                + "WHERE id = ?";

            PreparedStatement stFondo =
                conexion.prepareStatement(
                    sqlFondo
                );

            stFondo.setInt(1, idCorte);

            ResultSet rsFondo =
                stFondo.executeQuery();

            double fondoInicial = 0;

            if(rsFondo.next()) {

                fondoInicial =
                    rsFondo.getDouble(
                        "fondo_inicial"
                    );
            }

            double totalSistema =
                fondoInicial + totalVentas;

            double diferencia =
                totalEfectivo - totalSistema;

            // Cerrar corte
            String sql =
                "UPDATE cortes_caja SET "
                + "hora_cierre = GETDATE(), "
                + "total_ventas = ?, "
                + "total_efectivo = ?, "
                + "total_sistema = ?, "
                + "diferencia = ?, "
                + "num_ventas = ?, "
                + "observaciones = ?, "
                + "estado = 'CERRADO' "
                + "WHERE id = ?";

            PreparedStatement statement =
                conexion.prepareStatement(sql);

            statement.setDouble(1, totalVentas);

            statement.setDouble(
                2, totalEfectivo
            );

            statement.setDouble(3, totalSistema);

            statement.setDouble(4, diferencia);

            statement.setInt(5, numVentas);

            statement.setString(
                6, observaciones
            );

            statement.setInt(7, idCorte);

            statement.executeUpdate();

            conexion.close();

            return true;

        } catch (Exception e) {

            ErrorControlador.registrarEnLog(
                "Error al cerrar corte",
                e
            );

            return false;
        }
    }

    public boolean hayCorteAbierto() {

        try {

            Connection conexion =
                Conexion.conectar();

            String sql =
                "SELECT COUNT(*) AS total "
                + "FROM cortes_caja "
                + "WHERE estado = 'ABIERTO'";

            PreparedStatement statement =
                conexion.prepareStatement(sql);

            ResultSet resultado =
                statement.executeQuery();

            if(resultado.next()) {

                boolean abierto =
                    resultado.getInt("total") > 0;

                conexion.close();

                return abierto;
            }

            conexion.close();

            return false;

        } catch (Exception e) {

            ErrorControlador.registrarEnLog(
                "Error al verificar corte",
                e
            );

            return false;
        }
    }

    public int obtenerIdCorteAbierto() {

        try {

            Connection conexion =
                Conexion.conectar();

            String sql =
                "SELECT TOP 1 id "
                + "FROM cortes_caja "
                + "WHERE estado = 'ABIERTO' "
                + "ORDER BY id DESC";

            PreparedStatement statement =
                conexion.prepareStatement(sql);

            ResultSet resultado =
                statement.executeQuery();

            if(resultado.next()) {

                int id = resultado.getInt("id");

                conexion.close();

                return id;
            }

            conexion.close();

            return -1;

        } catch (Exception e) {

            ErrorControlador.registrarEnLog(
                "Error al obtener corte abierto",
                e
            );

            return -1;
        }
    }

    public DefaultTableModel listarCortes() {

        try {

            Connection conexion =
                Conexion.conectar();

            String sql =
                "SELECT * FROM cortes_caja "
                + "ORDER BY id DESC";

            PreparedStatement statement =
                conexion.prepareStatement(sql);

            ResultSet resultado =
                statement.executeQuery();

            String[] columnas = {
                "ID",
                "Fecha",
                "Apertura",
                "Cierre",
                "Fondo Inicial",
                "Ventas",
                "Total Sistema",
                "Efectivo Contado",
                "Diferencia",
                "Num Ventas",
                "Estado"
            };

            DefaultTableModel modelo =
                new DefaultTableModel(
                    null, columnas
                );

            while(resultado.next()) {

                Object[] fila = {
                    resultado.getInt("id"),
                    resultado.getString("fecha"),
                    resultado.getString(
                        "hora_apertura"
                    ),
                    resultado.getString(
                        "hora_cierre"
                    ),
                    resultado.getDouble(
                        "fondo_inicial"
                    ),
                    resultado.getDouble(
                        "total_ventas"
                    ),
                    resultado.getDouble(
                        "total_sistema"
                    ),
                    resultado.getDouble(
                        "total_efectivo"
                    ),
                    resultado.getDouble(
                        "diferencia"
                    ),
                    resultado.getInt("num_ventas"),
                    resultado.getString("estado")
                };

                modelo.addRow(fila);
            }

            conexion.close();

            return modelo;

        } catch (Exception e) {

            ErrorControlador.registrarEnLog(
                "Error al listar cortes",
                e
            );

            return null;
        }
    }

    public Object[] obtenerResumenCorteAbierto() {

        try {

            Connection conexion =
                Conexion.conectar();

            String sql =
                "SELECT "
                + "cc.id, "
                + "cc.fondo_inicial, "
                + "cc.hora_apertura, "
                + "COUNT(v.id) AS num_ventas, "
                + "ISNULL(SUM(v.monto_pagar),0) "
                + "AS total_ventas "
                + "FROM cortes_caja cc "
                + "LEFT JOIN ventas v "
                + "ON CAST(v.fecha AS DATE) "
                + "= CAST(cc.hora_apertura AS DATE) "
                + "WHERE cc.estado = 'ABIERTO' "
                + "GROUP BY cc.id, "
                + "cc.fondo_inicial, "
                + "cc.hora_apertura";

            PreparedStatement statement =
                conexion.prepareStatement(sql);

            ResultSet resultado =
                statement.executeQuery();

            if(resultado.next()) {

                Object[] datos = {
                    resultado.getInt("id"),
                    resultado.getDouble(
                        "fondo_inicial"
                    ),
                    resultado.getString(
                        "hora_apertura"
                    ),
                    resultado.getInt("num_ventas"),
                    resultado.getDouble(
                        "total_ventas"
                    )
                };

                conexion.close();

                return datos;
            }

            conexion.close();

            return null;

        } catch (Exception e) {

            ErrorControlador.registrarEnLog(
                "Error al obtener resumen corte",
                e
            );

            return null;
        }
    }
}