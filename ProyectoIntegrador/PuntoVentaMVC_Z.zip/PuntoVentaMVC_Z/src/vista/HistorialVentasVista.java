package vista;

import java.awt.Color;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class HistorialVentasVista extends JPanel {

    private static final long serialVersionUID = 1L;
    private JTable tablaVentas;

    private static final Color COLOR_FONDO =
        new Color(241, 245, 249);

    private static final Color COLOR_HEADER =
        new Color(71, 85, 105);

    private static final Color COLOR_ACENTO =
        new Color(37, 99, 235);

    public HistorialVentasVista() {

        setLayout(null);
        setBounds(0, 0, 960, 700);

        setBackground(new Color(241, 245, 249));

        // ==================
        // HEADER
        // ==================

        JPanel panelHeader = new JPanel();

        panelHeader.setBackground(COLOR_HEADER);

        panelHeader.setLayout(null);

        panelHeader.setBounds(0, 0, 960, 75);

        add(panelHeader);



        JPanel barraAcento = new JPanel();

        barraAcento.setBackground(COLOR_ACENTO);

        barraAcento.setBounds(0, 0, 4, 75);

        panelHeader.add(barraAcento);



        JLabel lblTitulo = new JLabel(
            "Historial de Ventas"
        );

        lblTitulo.setForeground(Color.WHITE);

        lblTitulo.setFont(
            new Font("Arial Black", Font.BOLD, 22)
        );

        lblTitulo.setBounds(25, 14, 400, 30);

        panelHeader.add(lblTitulo);



        JLabel lblSub = new JLabel(
            "Consulta todas las ventas registradas"
        );

        lblSub.setForeground(
            new Color(203, 213, 225)
        );

        lblSub.setFont(
            new Font("Arial", Font.PLAIN, 12)
        );

        lblSub.setBounds(25, 46, 400, 18);

        panelHeader.add(lblSub);



        JLabel lblHint = new JLabel(
            "Doble clic en una venta para ver su detalle"
        );

        lblHint.setForeground(
            new Color(148, 163, 184)
        );

        lblHint.setFont(
            new Font("Arial", Font.ITALIC, 11)
        );

        lblHint.setBounds(500, 28, 400, 18);

        panelHeader.add(lblHint);



        // ==================
        // PANEL TABLA
        // ==================

        JPanel panelTabla = new JPanel();

        panelTabla.setBackground(Color.WHITE);

        panelTabla.setLayout(null);

        panelTabla.setBounds(20, 90, 920, 450);

        panelTabla.setBorder(
            BorderFactory.createLineBorder(
                new Color(226, 232, 240)
            )
        );

        add(panelTabla);



        JPanel barraTabla = new JPanel();

        barraTabla.setBackground(COLOR_ACENTO);

        barraTabla.setBounds(0, 0, 4, 450);

        panelTabla.add(barraTabla);



        JLabel lblTabTit = new JLabel(
            "Registro de ventas"
        );

        lblTabTit.setFont(
            new Font("Arial", Font.BOLD, 13)
        );

        lblTabTit.setForeground(
            new Color(30, 41, 59)
        );

        lblTabTit.setBounds(15, 12, 300, 20);

        panelTabla.add(lblTabTit);



        JPanel lineaTabla = new JPanel();

        lineaTabla.setBackground(
            new Color(226, 232, 240)
        );

        lineaTabla.setBounds(15, 36, 890, 1);

        panelTabla.add(lineaTabla);



        JScrollPane scroll = new JScrollPane();

        scroll.setBounds(8, 42, 900, 398);

        scroll.setBorder(null);

        panelTabla.add(scroll);



        tablaVentas = new JTable() {

            private static final long
                serialVersionUID = 1L;

            @Override
            public boolean isCellEditable(
                int row,
                int column
            ) {
                return false;
            }
        };

        tablaVentas.setRowHeight(30);

        tablaVentas.setFont(
            new Font("Arial", Font.PLAIN, 13)
        );

        tablaVentas.getTableHeader().setFont(
            new Font("Arial", Font.BOLD, 13)
        );

        tablaVentas.getTableHeader()
            .setBackground(
                new Color(241, 245, 249)
            );

        tablaVentas.setGridColor(
            new Color(241, 245, 249)
        );

        tablaVentas.setSelectionBackground(
            new Color(219, 234, 254)
        );

        tablaVentas.setSelectionForeground(
            new Color(30, 64, 175)
        );

        scroll.setViewportView(tablaVentas);
    }

    public JTable getTablaVentas() {
        return tablaVentas;
    }
}