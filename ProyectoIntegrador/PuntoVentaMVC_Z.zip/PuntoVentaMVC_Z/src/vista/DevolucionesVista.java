package vista;

import java.awt.Color;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

public class DevolucionesVista extends JPanel {

    private static final long serialVersionUID = 1L;

    private JTextField txtIdVenta;

    private JTextField txtIdProducto;

    private JTextField txtCantidad;

    private JTextField txtMotivo;

    private JButton btnProcesar;

    private JButton btnReimprimir;

    private JTable tblVentas;

    private JTable tblDevoluciones;

    private static final Color COLOR_AZUL =
        new Color(37, 99, 235);

    private static final Color COLOR_ROJO =
        new Color(220, 38, 38);

    private static final Color COLOR_NARANJA =
        new Color(234, 88, 12);

    public DevolucionesVista() {

        setLayout(null);

        setBounds(0, 0, 960, 700);

        setBackground(new Color(241, 245, 249));



        JPanel panelHeader = new JPanel();

        panelHeader.setBackground(COLOR_ROJO);

        panelHeader.setBounds(0, 0, 960, 70);

        panelHeader.setLayout(null);

        add(panelHeader);



        JLabel lblTitulo = new JLabel(
            "Devoluciones y Reimpresion de Recibos"
        );

        lblTitulo.setFont(
            new Font("Arial", Font.BOLD, 22)
        );

        lblTitulo.setForeground(Color.WHITE);

        lblTitulo.setBounds(30, 18, 600, 35);

        panelHeader.add(lblTitulo);



        // Panel historial ventas
        JLabel lblV = new JLabel(
            "Historial de Ventas (doble clic para detalles)"
        );

        lblV.setFont(
            new Font("Arial", Font.BOLD, 14)
        );

        lblV.setBounds(20, 85, 500, 25);

        add(lblV);



        JScrollPane scrollVentas = new JScrollPane();

        scrollVentas.setBounds(20, 112, 430, 200);

        add(scrollVentas);



        tblVentas = new JTable() {

            private static final long
                serialVersionUID = 1L;

            @Override
            public boolean isCellEditable(
                int row,
                int column
            ) {
                return false;
            }
        };

        tblVentas.setRowHeight(28);

        tblVentas.setFont(
            new Font("Arial", Font.PLAIN, 13)
        );

        tblVentas.getTableHeader().setFont(
            new Font("Arial", Font.BOLD, 12)
        );

        scrollVentas.setViewportView(tblVentas);



        // Panel devolución
        JPanel panelForm = new JPanel();

        panelForm.setBackground(Color.WHITE);

        panelForm.setBounds(470, 85, 470, 230);

        panelForm.setLayout(null);

        panelForm.setBorder(
            BorderFactory.createLineBorder(
                new Color(226, 232, 240)
            )
        );

        add(panelForm);



        JLabel lblTitForm = new JLabel(
            "Procesar Devolución"
        );

        lblTitForm.setFont(
            new Font("Arial", Font.BOLD, 16)
        );

        lblTitForm.setBounds(15, 12, 280, 28);

        panelForm.add(lblTitForm);



        JLabel lblIdV = new JLabel("ID Venta");

        lblIdV.setFont(
            new Font("Arial", Font.BOLD, 13)
        );

        lblIdV.setBounds(15, 50, 100, 22);

        panelForm.add(lblIdV);



        txtIdVenta = new JTextField();

        txtIdVenta.setBounds(15, 74, 90, 36);

        txtIdVenta.setFont(
            new Font("Arial", Font.PLAIN, 14)
        );

        txtIdVenta.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(
                    new Color(203, 213, 225)
                ),
                BorderFactory.createEmptyBorder(
                    5, 8, 5, 8
                )
            )
        );

        panelForm.add(txtIdVenta);



        JLabel lblIdP = new JLabel("ID Producto");

        lblIdP.setFont(
            new Font("Arial", Font.BOLD, 13)
        );

        lblIdP.setBounds(115, 50, 110, 22);

        panelForm.add(lblIdP);



        txtIdProducto = new JTextField();

        txtIdProducto.setBounds(115, 74, 100, 36);

        txtIdProducto.setFont(
            new Font("Arial", Font.PLAIN, 14)
        );

        txtIdProducto.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(
                    new Color(203, 213, 225)
                ),
                BorderFactory.createEmptyBorder(
                    5, 8, 5, 8
                )
            )
        );

        panelForm.add(txtIdProducto);



        JLabel lblCant = new JLabel("Cantidad");

        lblCant.setFont(
            new Font("Arial", Font.BOLD, 13)
        );

        lblCant.setBounds(225, 50, 100, 22);

        panelForm.add(lblCant);



        txtCantidad = new JTextField();

        txtCantidad.setBounds(225, 74, 90, 36);

        txtCantidad.setFont(
            new Font("Arial", Font.PLAIN, 14)
        );

        txtCantidad.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(
                    new Color(203, 213, 225)
                ),
                BorderFactory.createEmptyBorder(
                    5, 8, 5, 8
                )
            )
        );

        panelForm.add(txtCantidad);



        JLabel lblMotivo = new JLabel(
            "Motivo de la devolución"
        );

        lblMotivo.setFont(
            new Font("Arial", Font.BOLD, 13)
        );

        lblMotivo.setBounds(15, 125, 250, 22);

        panelForm.add(lblMotivo);



        txtMotivo = new JTextField();

        txtMotivo.setBounds(15, 149, 290, 36);

        txtMotivo.setFont(
            new Font("Arial", Font.PLAIN, 14)
        );

        txtMotivo.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(
                    new Color(203, 213, 225)
                ),
                BorderFactory.createEmptyBorder(
                    5, 8, 5, 8
                )
            )
        );

        panelForm.add(txtMotivo);



        btnProcesar = new JButton(
            "Procesar Devolución"
        );

        btnProcesar.setBounds(315, 149, 140, 36);

        btnProcesar.setBackground(COLOR_ROJO);

        btnProcesar.setForeground(Color.WHITE);

        btnProcesar.setFont(
            new Font("Arial", Font.BOLD, 13)
        );

        btnProcesar.setFocusPainted(false);

        btnProcesar.setBorderPainted(false);

        panelForm.add(btnProcesar);



        btnReimprimir = new JButton(
            "Reimprimir Recibo"
        );

        btnReimprimir.setBounds(15, 195, 200, 25);

        btnReimprimir.setBackground(COLOR_AZUL);

        btnReimprimir.setForeground(Color.WHITE);

        btnReimprimir.setFont(
            new Font("Arial", Font.BOLD, 12)
        );

        btnReimprimir.setFocusPainted(false);

        btnReimprimir.setBorderPainted(false);

        panelForm.add(btnReimprimir);



        // Historial devoluciones
        JLabel lblD = new JLabel(
            "Historial de Devoluciones"
        );

        lblD.setFont(
            new Font("Arial", Font.BOLD, 14)
        );

        lblD.setBounds(20, 330, 350, 25);

        add(lblD);



        JScrollPane scrollDev = new JScrollPane();

        scrollDev.setBounds(20, 358, 920, 270);

        add(scrollDev);



        tblDevoluciones = new JTable() {

            private static final long
                serialVersionUID = 1L;

            @Override
            public boolean isCellEditable(
                int row,
                int column
            ) {
                return false;
            }
        };

        tblDevoluciones.setRowHeight(28);

        tblDevoluciones.setFont(
            new Font("Arial", Font.PLAIN, 13)
        );

        tblDevoluciones.getTableHeader().setFont(
            new Font("Arial", Font.BOLD, 12)
        );

        scrollDev.setViewportView(tblDevoluciones);
    }

    public JTextField getTxtIdVenta() {
        return txtIdVenta;
    }

    public JTextField getTxtIdProducto() {
        return txtIdProducto;
    }

    public JTextField getTxtCantidad() {
        return txtCantidad;
    }

    public JTextField getTxtMotivo() {
        return txtMotivo;
    }

    public JButton getBtnProcesar() {
        return btnProcesar;
    }

    public JButton getBtnReimprimir() {
        return btnReimprimir;
    }

    public JTable getTblVentas() {
        return tblVentas;
    }

    public JTable getTblDevoluciones() {
        return tblDevoluciones;
    }
}