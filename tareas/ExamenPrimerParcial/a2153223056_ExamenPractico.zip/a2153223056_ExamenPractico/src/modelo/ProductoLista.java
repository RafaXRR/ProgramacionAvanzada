package modelo;

import java.util.ArrayList;
import java.util.Iterator;

public class ProductoLista {

    private ArrayList<Producto> lista;

    public ProductoLista() {
        lista = new ArrayList<>();
    }

    public ArrayList<Producto> getLista() {
        return lista;
    }

    public void insertar(Producto p) {
        lista.add(p);
    }

    public Producto buscar(int id) {

        for (Producto p : lista) {
            if (p.getId() == id) {
                return p;
            }
        }

        return null;
    }

    public boolean existe(String codigo) {

        Iterator<Producto> it = lista.iterator();

        while (it.hasNext()) {

            Producto p = it.next();

            if (p.getCodigo().equalsIgnoreCase(codigo)) {
                return true;
            }

        }

        return false;
    }

    public void eliminar(int id) {

        Iterator<Producto> it = lista.iterator();

        while (it.hasNext()) {

            Producto p = it.next();

            if (p.getId() == id) {
                it.remove();
                break;
            }

        }

    }

    public void actualizar(Producto nuevo) {

        for (int i = 0; i < lista.size(); i++) {

            if (lista.get(i).getId() == nuevo.getId()) {

                lista.set(i, nuevo);
                break;

            }

        }

    }

}