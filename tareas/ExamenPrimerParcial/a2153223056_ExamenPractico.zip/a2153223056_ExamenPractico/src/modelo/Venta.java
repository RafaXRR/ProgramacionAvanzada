package modelo;

import javax.swing.table.DefaultTableModel;
import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Venta {

    private static final double IVA = 0.16;

    public double calcularSubtotal(DefaultTableModel modeloVenta){

        double subtotal = 0;

        for(int i=0;i<modeloVenta.getRowCount();i++){
            subtotal += Double.parseDouble(modeloVenta.getValueAt(i,3).toString());
        }

        return subtotal;
    }

    public double calcularIVA(double subtotal){
        return subtotal * IVA;
    }

    public double calcularTotal(double subtotal){
        return subtotal + calcularIVA(subtotal);
    }

    public void generarTicket(DefaultTableModel modeloVenta, double subtotal, double iva, double total){

        try{

            File dir = new File("tickets");
            if(!dir.exists()) dir.mkdirs();

            File contador = new File("tickets/contador.txt");

            int numVenta = 1;

            if(contador.exists()){

                BufferedReader br = new BufferedReader(new FileReader(contador));
                numVenta = Integer.parseInt(br.readLine()) + 1;
                br.close();

            }

            BufferedWriter bwCont = new BufferedWriter(new FileWriter(contador));
            bwCont.write(String.valueOf(numVenta));
            bwCont.close();

            String nombreArchivo = "tickets/ticket_" + numVenta + ".txt";

            BufferedWriter bw = new BufferedWriter(new FileWriter(nombreArchivo));

            bw.write("===== TICKET DE VENTA =====\n");
            bw.write("Número de venta: " + numVenta + "\n");
            bw.write("Fecha: " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")) + "\n\n");

            bw.write(String.format("%-20s %-10s %-10s %-10s\n","Producto","Precio","Cant","Subtotal"));

            for(int i=0;i<modeloVenta.getRowCount();i++){

                String nombre = modeloVenta.getValueAt(i,0).toString();
                double precio = Double.parseDouble(modeloVenta.getValueAt(i,1).toString());
                int cantidad = Integer.parseInt(modeloVenta.getValueAt(i,2).toString());
                double subtotalProducto = Double.parseDouble(modeloVenta.getValueAt(i,3).toString());

                bw.write(String.format("%-20s %-10.2f %-10d %-10.2f\n",
                        nombre,precio,cantidad,subtotalProducto));
            }

            bw.write(String.format("\nSubtotal: $%.2f\nIVA (16%%): $%.2f\nTOTAL: $%.2f\n",
                    subtotal,iva,total));

            bw.write("============================\n");

            bw.close();

        }catch(Exception e){
            e.printStackTrace();
        }

    }

}