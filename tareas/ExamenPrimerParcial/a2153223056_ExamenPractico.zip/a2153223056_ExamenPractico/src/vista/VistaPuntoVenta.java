package vista;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import controlador.ControladorSistema;
import modelo.Producto;
import modelo.Venta;

import java.awt.*;

public class VistaPuntoVenta extends JInternalFrame {

    private JTable tablaProductos;
    private JTable tablaVenta;

    private DefaultTableModel modeloProductos;
    private DefaultTableModel modeloVenta;

    private ControladorSistema controlador;
    private Venta venta;

    public VistaPuntoVenta(){

        setTitle("Punto de Venta");
        setSize(950,500);
        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);

        controlador = new ControladorSistema();
        venta = new Venta();

        setLayout(new BorderLayout());

        // Barra de búsqueda
        JPanel panelBusqueda = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel lblBuscar = new JLabel("Buscar:");
        JTextField txtBuscar = new JTextField(20);
        panelBusqueda.add(lblBuscar);
        panelBusqueda.add(txtBuscar);
        add(panelBusqueda, BorderLayout.NORTH);

        // Panel tablas
        JPanel panelTablas = new JPanel(new GridLayout(1,2));

        // Tabla productos
        modeloProductos = new DefaultTableModel();
        modeloProductos.addColumn("ID");
        modeloProductos.addColumn("Producto");
        modeloProductos.addColumn("Precio");
        modeloProductos.addColumn("Stock");

        tablaProductos = new JTable(modeloProductos);

        // Tabla venta
        modeloVenta = new DefaultTableModel();
        modeloVenta.addColumn("Producto");
        modeloVenta.addColumn("Precio");
        modeloVenta.addColumn("Cantidad");
        modeloVenta.addColumn("Subtotal");

        tablaVenta = new JTable(modeloVenta);

        panelTablas.add(new JScrollPane(tablaProductos));
        panelTablas.add(new JScrollPane(tablaVenta));

        add(panelTablas, BorderLayout.CENTER);

        // Botones
        JPanel panelBotones = new JPanel();

        JButton btnAgregar = new JButton("Agregar");
        JButton btnEliminar = new JButton("Eliminar");
        JButton btnTotal = new JButton("Total");
        JButton btnFinalizar = new JButton("Finalizar Venta");

        panelBotones.add(btnAgregar);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnTotal);
        panelBotones.add(btnFinalizar);

        add(panelBotones, BorderLayout.SOUTH);

        // Eventos
        btnAgregar.addActionListener(e -> agregarProducto());
        btnEliminar.addActionListener(e -> eliminarProducto());
        btnTotal.addActionListener(e -> calcularTotal());
        btnFinalizar.addActionListener(e -> finalizarVenta());

        // Listener búsqueda
        txtBuscar.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {

            public void insertUpdate(javax.swing.event.DocumentEvent e){ filtrar(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e){ filtrar(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e){ filtrar(); }

            private void filtrar(){

                String texto = txtBuscar.getText().toLowerCase();

                modeloProductos.setRowCount(0);

                for(Producto p : controlador.listar()){

                    if(p.getNombre().toLowerCase().contains(texto) ||
                       p.getCodigo().toLowerCase().contains(texto)){

                        modeloProductos.addRow(new Object[]{
                                p.getId(),
                                p.getNombre(),
                                p.getPrecioVenta(),
                                p.getStock()
                        });

                    }

                }

            }

        });

        cargarProductos();

    }

    private void cargarProductos(){

        modeloProductos.setRowCount(0);

        for(Producto p : controlador.listar()){

            modeloProductos.addRow(new Object[]{
                    p.getId(),
                    p.getNombre(),
                    p.getPrecioVenta(),
                    p.getStock()
            });

        }

    }

    private void agregarProducto(){

        int fila = tablaProductos.getSelectedRow();

        if(fila == -1){
            JOptionPane.showMessageDialog(this,"Selecciona un producto");
            return;
        }

        int id = Integer.parseInt(tablaProductos.getValueAt(fila,0).toString());
        String nombre = tablaProductos.getValueAt(fila,1).toString();
        double precio = Double.parseDouble(tablaProductos.getValueAt(fila,2).toString());
        int stock = Integer.parseInt(tablaProductos.getValueAt(fila,3).toString());

        if(stock <= 0){
            JOptionPane.showMessageDialog(this,"Sin stock");
            return;
        }

        int cantidad = Integer.parseInt(JOptionPane.showInputDialog("Cantidad"));

        if(cantidad > stock){
            JOptionPane.showMessageDialog(this,"No hay suficiente stock");
            return;
        }

        double subtotal = precio * cantidad;

        modeloVenta.addRow(new Object[]{
                nombre,
                precio,
                cantidad,
                subtotal
        });

        controlador.descontarStock(id, cantidad);

        cargarProductos();

    }

    private void eliminarProducto(){

        int fila = tablaVenta.getSelectedRow();

        if(fila != -1){
            modeloVenta.removeRow(fila);
        }

    }

    private void calcularTotal(){

        double subtotal = venta.calcularSubtotal(modeloVenta);
        double iva = venta.calcularIVA(subtotal);
        double total = venta.calcularTotal(subtotal);

        JOptionPane.showMessageDialog(this,
                String.format("Subtotal: $%.2f\nIVA (16%%): $%.2f\nTotal: $%.2f",
                        subtotal, iva, total)
        );

    }

    private void finalizarVenta(){

        if(modeloVenta.getRowCount() == 0){
            JOptionPane.showMessageDialog(this,"No hay productos en la venta");
            return;
        }

        double subtotal = venta.calcularSubtotal(modeloVenta);
        double iva = venta.calcularIVA(subtotal);
        double total = venta.calcularTotal(subtotal);

        JOptionPane.showMessageDialog(this,"Venta realizada\nTotal: $" + total);

        venta.generarTicket(modeloVenta, subtotal, iva, total);

        modeloVenta.setRowCount(0);

    }

}