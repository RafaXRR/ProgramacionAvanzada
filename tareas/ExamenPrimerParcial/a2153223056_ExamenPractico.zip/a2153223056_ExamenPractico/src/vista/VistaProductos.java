package vista;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import controlador.ControladorSistema;
import modelo.Producto;

import java.awt.*;

public class VistaProductos extends JInternalFrame {

    private JTextField txtId;
    private JTextField txtCodigo;
    private JTextField txtNombre;
    private JTextField txtPrecio;
    private JTextField txtStock;
    private JTextArea txtDescripcion;

    private JComboBox<String> comboCategoria;

    private JRadioButton rbActivo;
    private JRadioButton rbInactivo;

    private JTable tabla;
    private DefaultTableModel modeloTabla;

    private ControladorSistema controlador;

    public VistaProductos() {

        setTitle("Gestión de Productos");
        setSize(900,500);
        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);

        controlador = new ControladorSistema();

        setLayout(new BorderLayout());

        JPanel panelFormulario = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5,5,5,5);

        JLabel lblId = new JLabel("ID");
        txtId = new JTextField(10);
        txtId.setEnabled(false);

        JLabel lblCodigo = new JLabel("Código");
        txtCodigo = new JTextField(10);

        JLabel lblNombre = new JLabel("Nombre");
        txtNombre = new JTextField(10);

        JLabel lblDescripcion = new JLabel("Descripción");
        txtDescripcion = new JTextArea(3,10);

        JLabel lblCategoria = new JLabel("Categoría");
        comboCategoria = new JComboBox<>();
        comboCategoria.addItem("Abarrotes");
        comboCategoria.addItem("Limpieza");
        comboCategoria.addItem("Bebidas");

        JLabel lblPrecio = new JLabel("Precio");
        txtPrecio = new JTextField(10);

        JLabel lblStock = new JLabel("Stock");
        txtStock = new JTextField(10);

        rbActivo = new JRadioButton("Activo");
        rbInactivo = new JRadioButton("Inactivo");

        ButtonGroup grupo = new ButtonGroup();
        grupo.add(rbActivo);
        grupo.add(rbInactivo);
        rbActivo.setSelected(true);

        gbc.gridx=0; gbc.gridy=0;
        panelFormulario.add(lblId,gbc);
        gbc.gridx=1;
        panelFormulario.add(txtId,gbc);

        gbc.gridx=0; gbc.gridy=1;
        panelFormulario.add(lblCodigo,gbc);
        gbc.gridx=1;
        panelFormulario.add(txtCodigo,gbc);

        gbc.gridx=0; gbc.gridy=2;
        panelFormulario.add(lblNombre,gbc);
        gbc.gridx=1;
        panelFormulario.add(txtNombre,gbc);

        gbc.gridx=0; gbc.gridy=3;
        panelFormulario.add(lblDescripcion,gbc);
        gbc.gridx=1;
        panelFormulario.add(new JScrollPane(txtDescripcion),gbc);

        gbc.gridx=0; gbc.gridy=4;
        panelFormulario.add(lblCategoria,gbc);
        gbc.gridx=1;
        panelFormulario.add(comboCategoria,gbc);

        gbc.gridx=0; gbc.gridy=5;
        panelFormulario.add(lblPrecio,gbc);
        gbc.gridx=1;
        panelFormulario.add(txtPrecio,gbc);

        gbc.gridx=0; gbc.gridy=6;
        panelFormulario.add(lblStock,gbc);
        gbc.gridx=1;
        panelFormulario.add(txtStock,gbc);

        gbc.gridx=0; gbc.gridy=7;
        panelFormulario.add(rbActivo,gbc);
        gbc.gridx=1;
        panelFormulario.add(rbInactivo,gbc);

        add(panelFormulario,BorderLayout.WEST);

        modeloTabla = new DefaultTableModel();
        modeloTabla.addColumn("ID");
        modeloTabla.addColumn("Código");
        modeloTabla.addColumn("Nombre");
        modeloTabla.addColumn("Categoría");
        modeloTabla.addColumn("Stock");
        modeloTabla.addColumn("Precio");

        tabla = new JTable(modeloTabla);

        tabla.getSelectionModel().addListSelectionListener(e -> {

            if(!e.getValueIsAdjusting()){

                int fila = tabla.getSelectedRow();

                if(fila != -1){

                    txtId.setText(tabla.getValueAt(fila,0).toString());
                    txtCodigo.setText(tabla.getValueAt(fila,1).toString());
                    txtNombre.setText(tabla.getValueAt(fila,2).toString());
                    comboCategoria.setSelectedItem(tabla.getValueAt(fila,3).toString());
                    txtStock.setText(tabla.getValueAt(fila,4).toString());
                    txtPrecio.setText(tabla.getValueAt(fila,5).toString());

                }

            }

        });

        add(new JScrollPane(tabla),BorderLayout.CENTER);

        JPanel panelBotones = new JPanel();

        JButton btnGuardar = new JButton("Guardar");
        JButton btnBuscar = new JButton("Buscar");
        JButton btnModificar = new JButton("Modificar");
        JButton btnEliminar = new JButton("Eliminar");
        JButton btnListar = new JButton("Listar");

        panelBotones.add(btnGuardar);
        panelBotones.add(btnBuscar);
        panelBotones.add(btnModificar);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnListar);

        add(panelBotones,BorderLayout.SOUTH);

        btnGuardar.addActionListener(e -> guardar());
        btnBuscar.addActionListener(e -> buscar());
        btnModificar.addActionListener(e -> modificar());
        btnEliminar.addActionListener(e -> eliminar());
        btnListar.addActionListener(e -> actualizarTabla());

        actualizarTabla();
    }

    private void actualizarTabla(){

        modeloTabla.setRowCount(0);

        for(Producto p : controlador.listar()){

            modeloTabla.addRow(new Object[]{
                    p.getId(),
                    p.getCodigo(),
                    p.getNombre(),
                    p.getCategoria(),
                    p.getStock(),
                    p.getPrecioVenta()
            });

        }

    }

    private void guardar(){

        try{

            if(txtCodigo.getText().isEmpty() ||
               txtNombre.getText().isEmpty() ||
               txtPrecio.getText().isEmpty() ||
               txtStock.getText().isEmpty()){

                JOptionPane.showMessageDialog(this,"Campos vacíos");
                return;
            }

            int id = controlador.generarId();

            Producto p = new Producto(
                    id,
                    txtCodigo.getText(),
                    txtNombre.getText(),
                    txtDescripcion.getText(),
                    comboCategoria.getSelectedItem().toString(),
                    Integer.parseInt(txtStock.getText()),
                    Double.parseDouble(txtPrecio.getText()),
                    rbActivo.isSelected()
            );

            boolean ok = controlador.guardar(p);

            if(!ok){
                JOptionPane.showMessageDialog(this,"Código duplicado");
                return;
            }

            actualizarTabla();
            limpiar();

        }catch(Exception e){
            JOptionPane.showMessageDialog(this,"Datos inválidos");
        }

    }

    private void buscar(){

    String input = JOptionPane.showInputDialog("ID o Nombre del producto");

    if(input == null || input.isEmpty()){
        return; // Si el usuario cancela o deja vacío
    }

    Producto p = null;

    try {
        // Primero intentamos buscar por ID
        int id = Integer.parseInt(input);
        p = controlador.buscar(id);
    } catch (NumberFormatException e) {
        // Si no es número, buscamos por nombre (coincidencia parcial)
        for(Producto prod : controlador.listar()){
            if(prod.getNombre().toLowerCase().contains(input.toLowerCase())){
                p = prod;
                break; // Se toma el primer producto que coincida
            }
        }
    }

    if(p != null){
        txtId.setText(String.valueOf(p.getId()));
        txtCodigo.setText(p.getCodigo());
        txtNombre.setText(p.getNombre());
        txtDescripcion.setText(p.getDescripcion());
        comboCategoria.setSelectedItem(p.getCategoria());
        txtStock.setText(String.valueOf(p.getStock()));
        txtPrecio.setText(String.valueOf(p.getPrecioVenta()));
        rbActivo.setSelected(p.isActivo());
        rbInactivo.setSelected(!p.isActivo());
    }else{
        JOptionPane.showMessageDialog(this,"Producto no encontrado");
    }
}

    private void modificar(){

        try{

            int id = Integer.parseInt(txtId.getText());

            Producto p = new Producto(
                    id,
                    txtCodigo.getText(),
                    txtNombre.getText(),
                    txtDescripcion.getText(),
                    comboCategoria.getSelectedItem().toString(),
                    Integer.parseInt(txtStock.getText()),
                    Double.parseDouble(txtPrecio.getText()),
                    rbActivo.isSelected()
            );

            controlador.modificar(p);

            actualizarTabla();
            limpiar();

        }catch(Exception e){
            JOptionPane.showMessageDialog(this,"Error al modificar");
        }

    }

    private void eliminar(){

        try{

            int id = Integer.parseInt(txtId.getText());

            int r = JOptionPane.showConfirmDialog(
                    this,
                    "¿Eliminar producto?",
                    "Confirmar",
                    JOptionPane.YES_NO_OPTION
            );

            if(r == JOptionPane.YES_OPTION){

                controlador.eliminar(id);

                actualizarTabla();
                limpiar();

            }

        }catch(Exception e){
            JOptionPane.showMessageDialog(this,"Selecciona un producto");
        }

    }

    private void limpiar(){

        txtId.setText("");
        txtCodigo.setText("");
        txtNombre.setText("");
        txtDescripcion.setText("");
        txtPrecio.setText("");
        txtStock.setText("");

    }

}