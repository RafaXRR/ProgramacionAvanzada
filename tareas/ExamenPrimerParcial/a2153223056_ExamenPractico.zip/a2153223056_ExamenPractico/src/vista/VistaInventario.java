package vista;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import controlador.ControladorSistema;
import modelo.Producto;

import java.awt.*;

public class VistaInventario extends JInternalFrame {

    private JTable tabla;
    private DefaultTableModel modelo;

    private ControladorSistema controlador;

    public VistaInventario(){

        setTitle("Inventario");
        setSize(700,400);
        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);

        controlador = new ControladorSistema();

        setLayout(new BorderLayout());

        // Barra de búsqueda
        JPanel panelBusqueda = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel lblBuscar = new JLabel("Buscar:");
        JTextField txtBuscar = new JTextField(20);
        panelBusqueda.add(lblBuscar);
        panelBusqueda.add(txtBuscar);
        add(panelBusqueda, BorderLayout.NORTH);

        // Tabla
        modelo = new DefaultTableModel();
        modelo.addColumn("ID");
        modelo.addColumn("Código");
        modelo.addColumn("Producto");
        modelo.addColumn("Categoría");
        modelo.addColumn("Stock");

        tabla = new JTable(modelo);

        add(new JScrollPane(tabla),BorderLayout.CENTER);

        JButton btnActualizar = new JButton("Actualizar");
        btnActualizar.addActionListener(e -> cargarDatos());
        add(btnActualizar,BorderLayout.SOUTH);

        // Listener búsqueda
        txtBuscar.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e) { filtrar(); }
            public void removeUpdate(javax.swing.event.DocumentEvent e) { filtrar(); }
            public void changedUpdate(javax.swing.event.DocumentEvent e) { filtrar(); }

            private void filtrar() {
                String texto = txtBuscar.getText().toLowerCase();
                modelo.setRowCount(0);
                for(Producto p : controlador.listar()){
                    if(p.getNombre().toLowerCase().contains(texto) || p.getCodigo().toLowerCase().contains(texto)){
                        modelo.addRow(new Object[]{
                                p.getId(),
                                p.getCodigo(),
                                p.getNombre(),
                                p.getCategoria(),
                                p.getStock()
                        });
                    }
                }
            }
        });

        // Cargar productos inicial
        cargarDatos();
    }

    private void cargarDatos(){
        modelo.setRowCount(0);
        for(Producto p : controlador.listar()){
            modelo.addRow(new Object[]{
                    p.getId(),
                    p.getCodigo(),
                    p.getNombre(),
                    p.getCategoria(),
                    p.getStock()
            });
        }
    }

}