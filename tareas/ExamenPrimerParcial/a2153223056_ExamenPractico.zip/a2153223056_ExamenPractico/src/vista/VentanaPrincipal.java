package vista;

import javax.swing.*;

public class VentanaPrincipal extends JFrame {

    private JDesktopPane desktop;

    public VentanaPrincipal(){

        setTitle("Sistema de Ventas");
        setSize(1100,600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        desktop = new JDesktopPane();
        setContentPane(desktop);

        JMenuBar barra = new JMenuBar();

        JMenu menu = new JMenu("Módulos");

        JMenuItem productos = new JMenuItem("Productos");
        JMenuItem inventario = new JMenuItem("Inventario");
        JMenuItem puntoVenta = new JMenuItem("Punto de Venta");
        JMenuItem salir = new JMenuItem("Salir");

        menu.add(productos);
        menu.add(inventario);
        menu.add(puntoVenta);
        menu.addSeparator();
        menu.add(salir);

        barra.add(menu);

        setJMenuBar(barra);

        productos.addActionListener(e -> abrirProductos());
        inventario.addActionListener(e -> abrirInventario());
        puntoVenta.addActionListener(e -> abrirPuntoVenta());

        salir.addActionListener(e -> System.exit(0));

    }

    private void abrirProductos(){

        VistaProductos vp = new VistaProductos();

        desktop.add(vp);
        vp.setVisible(true);

    }

    private void abrirInventario(){

        VistaInventario vi = new VistaInventario();

        desktop.add(vi);
        vi.setVisible(true);

    }

    private void abrirPuntoVenta(){

        VistaPuntoVenta pv = new VistaPuntoVenta();

        desktop.add(pv);
        pv.setVisible(true);

    }


}