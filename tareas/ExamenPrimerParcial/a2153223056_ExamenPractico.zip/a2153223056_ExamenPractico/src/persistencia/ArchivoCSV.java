package persistencia;

import modelo.Producto;

import java.io.*;
import java.util.ArrayList;

public class ArchivoCSV {

    private static final String ARCHIVO = "productos.csv";

    public static void exportarCSV(ArrayList<Producto> lista){

        try{

            BufferedWriter bw = new BufferedWriter(new FileWriter(ARCHIVO));

            for(Producto p : lista){

                String linea =
                        p.getId()+","+
                        p.getCodigo()+","+
                        p.getNombre()+","+
                        p.getDescripcion()+","+
                        p.getCategoria()+","+
                        p.getStock()+","+
                        p.getPrecioVenta()+","+
                        p.isActivo();

                bw.write(linea);
                bw.newLine();

            }

            bw.close();

        }catch(Exception e){
            e.printStackTrace();
        }

    }

    public static ArrayList<Producto> importarCSV(){

        ArrayList<Producto> lista = new ArrayList<>();

        try{

            File archivo = new File(ARCHIVO);

            if(!archivo.exists()){
                return lista;
            }

            BufferedReader br = new BufferedReader(new FileReader(archivo));

            String linea;

            while((linea = br.readLine()) != null){

                String[] d = linea.split(",");

                int id = Integer.parseInt(d[0]);
                String codigo = d[1];
                String nombre = d[2];
                String descripcion = d[3];
                String categoria = d[4];
                int stock = Integer.parseInt(d[5]);
                double precio = Double.parseDouble(d[6]);
                boolean activo = Boolean.parseBoolean(d[7]);

                Producto p = new Producto(id,codigo,nombre,descripcion,categoria,stock,precio,activo);

                lista.add(p);

            }

            br.close();

        }catch(Exception e){
            e.printStackTrace();
        }

        return lista;

    }

}