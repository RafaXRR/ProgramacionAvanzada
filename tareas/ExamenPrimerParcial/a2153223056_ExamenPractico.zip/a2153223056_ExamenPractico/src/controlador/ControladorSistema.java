package controlador;

import modelo.Producto;
import modelo.ProductoLista;
import persistencia.ArchivoCSV;

import java.util.ArrayList;

public class ControladorSistema {

    private ProductoLista dao;

    public ControladorSistema(){

        dao = new ProductoLista();

        ArrayList<Producto> lista = ArchivoCSV.importarCSV();

        if(lista != null){
            dao.getLista().addAll(lista);
        }

    }

    public ArrayList<Producto> listar(){
        return dao.getLista();
    }

    public int generarId(){

        int mayor = 0;

        for(Producto p : dao.getLista()){

            if(p.getId() > mayor){
                mayor = p.getId();
            }

        }

        return mayor + 1;

    }

    public boolean guardar(Producto p){

        if(dao.existe(p.getCodigo())){
            return false;
        }

        dao.insertar(p);

        ArchivoCSV.exportarCSV(dao.getLista());

        return true;

    }

    public Producto buscar(int id){
        return dao.buscar(id);
    }

    public void modificar(Producto p){

        dao.actualizar(p);

        ArchivoCSV.exportarCSV(dao.getLista());

    }

    public void eliminar(int id){

        dao.eliminar(id);

        ArchivoCSV.exportarCSV(dao.getLista());

    }


    
    public void descontarStock(int id, int cantidad){

        Producto p = buscar(id);

        if(p != null){

            int nuevoStock = p.getStock() - cantidad;

            if(nuevoStock < 0){
                nuevoStock = 0;
            }

            p.setStock(nuevoStock);

            ArchivoCSV.exportarCSV(dao.getLista());

        }

    }
    
    

}

