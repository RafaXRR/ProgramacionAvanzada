package vista;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;

public class VistaInsumos extends JInternalFrame {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField txtNombre;
    private JTextField txtCantidad;

    private JButton btnGuardar;
    private JButton btnCerrar;

    public VistaInsumos() {

        setTitle("Gestión de Insumos");
        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);

        setBounds(100, 100, 400, 250);
        getContentPane().setLayout(null);

        JLabel lblNombre = new JLabel("Nombre:");
        lblNombre.setBounds(30, 30, 100, 25);
        getContentPane().add(lblNombre);

        txtNombre = new JTextField();
        txtNombre.setBounds(140, 30, 200, 25);
        getContentPane().add(txtNombre);

        JLabel lblCantidad = new JLabel("Cantidad:");
        lblCantidad.setBounds(30, 70, 100, 25);
        getContentPane().add(lblCantidad);

        txtCantidad = new JTextField();
        txtCantidad.setBounds(140, 70, 200, 25);
        getContentPane().add(txtCantidad);

        btnGuardar = new JButton("Guardar");
        btnGuardar.setBounds(80, 130, 100, 30);
        getContentPane().add(btnGuardar);

        btnCerrar = new JButton("Cerrar");
        btnCerrar.setBounds(200, 130, 100, 30);
        getContentPane().add(btnCerrar);

        // Cerrar ventana
        btnCerrar.addActionListener(e -> dispose());
    }

    // ===== GETTERS =====

    public JTextField getTxtNombre() {
        return txtNombre;
    }

    public JTextField getTxtCantidad() {
        return txtCantidad;
    }

    public JButton getBtnGuardar() {
        return btnGuardar;
    }
}
