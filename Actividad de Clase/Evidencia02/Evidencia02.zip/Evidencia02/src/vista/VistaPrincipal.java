package vista;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JDesktopPane;

public class VistaPrincipal extends JFrame {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
    private JDesktopPane desktopPane;

    private JMenuBar menuBar;
    private JMenu menuArchivo;
    private JMenu menuGestion;

    private JMenuItem itemInsumos;
    private JMenuItem itemObras;
    private JMenuItem itemSalir;

    public VistaPrincipal() {

        setTitle("Evidencia 02 - MDI");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 900, 600);

        // ===== MENU =====
        menuBar = new JMenuBar();
        setJMenuBar(menuBar);

        menuArchivo = new JMenu("Archivo");
        menuBar.add(menuArchivo);

        itemSalir = new JMenuItem("Salir");
        menuArchivo.add(itemSalir);

        menuGestion = new JMenu("Gestión");
        menuBar.add(menuGestion);

        itemInsumos = new JMenuItem("Insumos");
        menuGestion.add(itemInsumos);

        itemObras = new JMenuItem("Obras");
        menuGestion.add(itemObras);

        // ===== CONTENT =====
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        desktopPane = new JDesktopPane();
        desktopPane.setBounds(10, 10, 860, 520);
        contentPane.add(desktopPane);
    }

    // ===== GETTERS (MVC) =====

    public JDesktopPane getDesktopPane() {
        return desktopPane;
    }

    public JMenuItem getItemInsumos() {
        return itemInsumos;
    }

    public JMenuItem getItemObras() {
        return itemObras;
    }

    public JMenuItem getItemSalir() {
        return itemSalir;
    }

    public JMenu getMenuGestion() {
        return menuGestion;
    }
}
