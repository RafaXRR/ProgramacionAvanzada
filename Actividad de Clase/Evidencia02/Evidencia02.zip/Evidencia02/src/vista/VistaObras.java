package vista;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JButton;
import javax.swing.JScrollPane;

public class VistaObras extends JInternalFrame {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField txtNombreObra;
    private JComboBox<String> comboEstado;
    private JList<String> listaResponsables;
    private JButton btnGuardar;
    private JButton btnCerrar;

    public VistaObras() {

        setTitle("Gestión de Obras");
        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setResizable(true);

        setBounds(100, 100, 450, 300);
        getContentPane().setLayout(null);

        JLabel lblNombre = new JLabel("Nombre de la Obra:");
        lblNombre.setBounds(20, 20, 150, 25);
        getContentPane().add(lblNombre);

        txtNombreObra = new JTextField();
        txtNombreObra.setBounds(180, 20, 230, 25);
        getContentPane().add(txtNombreObra);

        JLabel lblEstado = new JLabel("Estado:");
        lblEstado.setBounds(20, 60, 150, 25);
        getContentPane().add(lblEstado);

        comboEstado = new JComboBox<>();
        comboEstado.setBounds(180, 60, 230, 25);
        comboEstado.addItem("Planeada");
        comboEstado.addItem("En proceso");
        comboEstado.addItem("Finalizada");
        getContentPane().add(comboEstado);

        JLabel lblResponsables = new JLabel("Responsables:");
        lblResponsables.setBounds(20, 100, 150, 25);
        getContentPane().add(lblResponsables);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(180, 100, 230, 80);
        getContentPane().add(scrollPane);

        listaResponsables = new JList<>();
        listaResponsables.setListData(new String[] {
            "Arquitecto",
            "Ingeniero",
            "Supervisor",
            "Residente"
        });
        scrollPane.setViewportView(listaResponsables);

        btnGuardar = new JButton("Guardar");
        btnGuardar.setBounds(110, 210, 100, 30);
        getContentPane().add(btnGuardar);

        btnCerrar = new JButton("Cerrar");
        btnCerrar.setBounds(230, 210, 100, 30);
        getContentPane().add(btnCerrar);

        btnCerrar.addActionListener(e -> dispose());
    }

    // ===== GETTERS =====

    public JTextField getTxtNombreObra() {
        return txtNombreObra;
    }

    public JComboBox<String> getComboEstado() {
        return comboEstado;
    }

    public JList<String> getListaResponsables() {
        return listaResponsables;
    }

    public JButton getBtnGuardar() {
        return btnGuardar;
    }
}
