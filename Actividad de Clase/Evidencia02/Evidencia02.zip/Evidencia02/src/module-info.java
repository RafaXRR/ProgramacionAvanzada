/**
 * 
 */
/**
 * 
 */
module Evidencia02 {
	requires java.desktop;
}