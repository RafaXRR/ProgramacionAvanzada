package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JInternalFrame;
import javax.swing.event.InternalFrameAdapter;
import javax.swing.event.InternalFrameEvent;

import vista.VistaPrincipal;
import util.LibreriaVentanas;
import vista.VistaInsumos;
import vista.VistaObras;

public class Controlador implements ActionListener {

    private VistaPrincipal vista;

    public Controlador() {
        vista = new VistaPrincipal();

        vista.getItemInsumos().addActionListener(this);
        vista.getItemObras().addActionListener(this);
        vista.getItemSalir().addActionListener(this);

        vista.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == vista.getItemInsumos()) {
            abrirVentana(new VistaInsumos());
        }

        if (e.getSource() == vista.getItemObras()) {
            abrirVentana(new VistaObras());
        }

        if (e.getSource() == vista.getItemSalir()) {
            vista.dispose();
        }
    }

    private void abrirVentana(JInternalFrame frame) {

        vista.getMenuGestion().setEnabled(false);

        vista.getDesktopPane().add(frame);
        frame.setVisible(true);

        // Centrar usando la librería (requisito del profe)
        LibreriaVentanas.centrar(vista.getDesktopPane(), frame);

        // Habilitar menú al cerrar la ventana
        frame.addInternalFrameListener(new InternalFrameAdapter() {
            @Override
            public void internalFrameClosed(InternalFrameEvent e) {
                vista.getMenuGestion().setEnabled(true);
            }
        });
    }
}
