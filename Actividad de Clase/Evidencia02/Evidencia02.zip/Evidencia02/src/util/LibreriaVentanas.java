package util;

import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;

public class LibreriaVentanas {

    public static void centrar(JDesktopPane desktop, JInternalFrame frame) {

        int x = (desktop.getWidth() - frame.getWidth()) / 2;
        int y = (desktop.getHeight() - frame.getHeight()) / 2;

        frame.setLocation(x, y);
    }
}
