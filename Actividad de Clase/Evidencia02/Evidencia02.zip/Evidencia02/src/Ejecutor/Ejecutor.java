package Ejecutor;

import controlador.Controlador;

public class Ejecutor {

    public static void main(String[] args) {

        new Controlador();
    }
}
