package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

import modelo.Insumo;
import modelo.ListaInsumo;
import vista.Vista;

public class Controlador implements ActionListener {

    private Vista vista;
    private ListaInsumo modelo;

    public Controlador() {

        vista = new Vista();
        modelo = new ListaInsumo();

        vista.getComboCategoria().setModel(modelo.getCategorias());
        vista.getListInsumos().setModel(modelo.getLista());

        vista.getBtnAgregar().addActionListener(this);
        vista.getBtnEliminar().addActionListener(this);
        vista.getBtnSalir().addActionListener(this);

        vista.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        // AGREGAR
        if (e.getSource() == vista.getBtnAgregar()) {
            try {
                int id = Integer.parseInt(vista.getTxtId().getText());
                String nombre = vista.getTxtInsumo().getText().trim();
                String categoria = vista.getComboCategoria().getSelectedItem().toString();

                if (nombre.isEmpty()) {
                    JOptionPane.showMessageDialog(vista, "Ingrese el insumo");
                    return;
                }

                modelo.agregar(new Insumo(id, nombre, categoria));
                vista.limpiar();

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(vista, "ID inválido");
            }
        }

        // ELIMINAR
        if (e.getSource() == vista.getBtnEliminar()) {
            int index = vista.getListInsumos().getSelectedIndex();

            if (index < 0) {
                JOptionPane.showMessageDialog(vista, "Seleccione un elemento");
            } else {
                modelo.eliminar(index);
            }
        }

        // SALIR
        if (e.getSource() == vista.getBtnSalir()) {
            vista.dispose();
        }
    }
}
