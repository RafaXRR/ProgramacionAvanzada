package modelo;

public class Insumo {

    private int id;
    private String insumo;
    private String categoria;

    public Insumo(int id, String insumo, String categoria) {
        this.id = id;
        this.insumo = insumo;
        this.categoria = categoria;
    }

    @Override
    public String toString() {
        return id + " - " + insumo + " - " + categoria;
    }
}
