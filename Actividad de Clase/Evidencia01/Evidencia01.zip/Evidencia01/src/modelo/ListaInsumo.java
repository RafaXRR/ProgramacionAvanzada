package modelo;

import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;

public class ListaInsumo {

    private DefaultListModel<Insumo> lista;
    private DefaultComboBoxModel<String> categorias;

    public ListaInsumo() {
        lista = new DefaultListModel<>();
        categorias = new DefaultComboBoxModel<>();

        categorias.addElement("Materiales");
        categorias.addElement("Mano de Obra");
        categorias.addElement("Herramienta");
        categorias.addElement("Servicios");
    }

    public void agregar(Insumo i) {
        lista.addElement(i);
    }

    public void eliminar(int index) {
        if (index >= 0) {
            lista.remove(index);
        }
    }

    public DefaultListModel<Insumo> getLista() {
        return lista;
    }

    public DefaultComboBoxModel<String> getCategorias() {
        return categorias;
    }
}
