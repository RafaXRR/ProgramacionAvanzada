package ejecutor;

import controlador.Controlador;

public class Ejecutor {

    public static void main(String[] args) {
        try {
            new Controlador();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
