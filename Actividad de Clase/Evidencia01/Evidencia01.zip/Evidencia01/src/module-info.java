/**
 * 
 */
/**
 * 
 */
module Evidencia01 {
	requires java.desktop;
}