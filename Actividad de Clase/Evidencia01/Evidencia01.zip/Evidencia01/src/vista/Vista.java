package vista;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.JScrollPane;

import modelo.Insumo;

public class Vista extends JFrame {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
    private JTextField txtId;
    private JTextField txtInsumo;
    private JComboBox<String> comboCategoria;
    private JList<Insumo> listInsumos;
    private JButton btnAgregar;
    private JButton btnEliminar;
    private JButton btnSalir;

    /**
     * Create the frame.
     */
    public Vista() {
        setTitle("CRUD Insumos");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 520, 380);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // ===== LABEL ID =====
        JLabel lblId = new JLabel("ID:");
        lblId.setBounds(20, 20, 80, 20);
        contentPane.add(lblId);

        txtId = new JTextField();
        txtId.setBounds(100, 20, 120, 22);
        contentPane.add(txtId);
        txtId.setColumns(10);

        // ===== LABEL INSUMO =====
        JLabel lblInsumo = new JLabel("Insumo:");
        lblInsumo.setBounds(20, 55, 80, 20);
        contentPane.add(lblInsumo);

        txtInsumo = new JTextField();
        txtInsumo.setBounds(100, 55, 200, 22);
        contentPane.add(txtInsumo);
        txtInsumo.setColumns(10);

        // ===== LABEL CATEGORIA =====
        JLabel lblCategoria = new JLabel("Categoría:");
        lblCategoria.setBounds(20, 90, 80, 20);
        contentPane.add(lblCategoria);

        comboCategoria = new JComboBox<>();
        comboCategoria.setBounds(100, 90, 200, 22);
        contentPane.add(comboCategoria);

        // ===== BOTONES =====
        btnAgregar = new JButton("Agregar");
        btnAgregar.setBounds(330, 20, 140, 25);
        contentPane.add(btnAgregar);

        btnEliminar = new JButton("Eliminar");
        btnEliminar.setBounds(330, 55, 140, 25);
        contentPane.add(btnEliminar);

        btnSalir = new JButton("Salir");
        btnSalir.setBounds(330, 90, 140, 25);
        contentPane.add(btnSalir);

        // ===== LISTA + SCROLL =====
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(20, 140, 450, 180);
        contentPane.add(scrollPane);

        listInsumos = new JList<>();
        scrollPane.setViewportView(listInsumos);
    }

    // ====== MÉTODOS PUENTE (MVC) ======

    public JTextField getTxtId() {
        return txtId;
    }

    public JTextField getTxtInsumo() {
        return txtInsumo;
    }

    public JComboBox<String> getComboCategoria() {
        return comboCategoria;
    }

    public JList<Insumo> getListInsumos() {
        return listInsumos;
    }

    public JButton getBtnAgregar() {
        return btnAgregar;
    }

    public JButton getBtnEliminar() {
        return btnEliminar;
    }

    public JButton getBtnSalir() {
        return btnSalir;
    }

    // ===== UTILIDAD =====
    public void limpiar() {
        txtId.setText("");
        txtInsumo.setText("");
        txtId.requestFocus();
    }
}
