package persistencia;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {

    private static final String URL =

        "jdbc:sqlserver://localhost\\SQLEXPRESS;"
        + "databaseName=PuntoVenta;"
        + "encrypt=true;"
        + "trustServerCertificate=true;";

    private static final String USUARIO =
        "sa";

    private static final String PASSWORD =
        "1234";

    public static Connection conectar() {

        try {

            Connection conexion =

                DriverManager.getConnection(
                    URL,
                    USUARIO,
                    PASSWORD
                );

            System.out.println(
                "Conexión exitosa"
            );

            return conexion;

        } catch (SQLException e) {

            System.out.println(
                "Error de conexión"
            );

            e.printStackTrace();

            return null;
        }
    }
}