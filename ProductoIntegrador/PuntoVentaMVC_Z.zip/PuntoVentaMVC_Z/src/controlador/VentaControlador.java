package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import modelo.Producto;
import persistencia.ProductoPersistencia;
import persistencia.VentaPersistencia;
import util.ErrorControlador;
import vista.TicketVista;
import vista.VentasVista;

public class VentaControlador
    implements ActionListener {

    private VentasVista vista;

    private DefaultTableModel modelo;

    private double subtotal = 0;

    private ProductoPersistencia persistencia;

    private VentaPersistencia ventaPersistencia;

    public VentaControlador(
        VentasVista vista
    ) {

        this.vista = vista;

        persistencia =
            new ProductoPersistencia();

        ventaPersistencia =
            new VentaPersistencia();

        String[] columnas = {
            "ID",
            "Producto",
            "Cantidad",
            "Precio",
            "Subtotal"
        };

        modelo =
            new DefaultTableModel(
                null,
                columnas
            );

        this.vista
            .getTablaVenta()
            .setModel(modelo);

        this.vista
            .getBtnAgregar()
            .addActionListener(this);

        this.vista
            .getBtnVender()
            .addActionListener(this);

        this.vista
            .getBtnEliminarItem()
            .addActionListener(this);

        this.vista
            .getBtnLimpiar()
            .addActionListener(this);
    }

    @Override
    public void actionPerformed(
        ActionEvent e
    ) {

        if(
            e.getSource()
            ==
            vista.getBtnAgregar()
        ) {

            agregarProducto();
        }

        if(
            e.getSource()
            ==
            vista.getBtnVender()
        ) {

            finalizarVenta();
        }

        if(
            e.getSource()
            ==
            vista.getBtnEliminarItem()
        ) {

            eliminarItemSeleccionado();
        }

        if(
            e.getSource()
            ==
            vista.getBtnLimpiar()
        ) {

            limpiarVenta();
        }
    }

    public void agregarProducto() {

        try {

            String txtId =
                vista
                .getTxtProducto()
                .getText()
                .trim();

            String txtCant =
                vista
                .getTxtCantidad()
                .getText()
                .trim();

            if(
                txtId.isEmpty()
                || txtCant.isEmpty()
            ) {

                ErrorControlador
                    .mostrarAdvertencia(
                        "Ingresa ID de producto "
                        + "y cantidad"
                    );

                return;
            }

            int idProducto =
                Integer.parseInt(txtId);

            int cantidad =
                Integer.parseInt(txtCant);

            if(cantidad <= 0) {

                ErrorControlador
                    .mostrarAdvertencia(
                        "La cantidad debe ser "
                        + "mayor a cero"
                    );

                return;
            }

            Producto producto =
                persistencia
                .obtenerProductoPorId(
                    idProducto
                );

            if(producto == null) {

                ErrorControlador
                    .mostrarAdvertencia(
                        "Producto no encontrado. "
                        + "ID: " + idProducto
                    );

                return;
            }

            if(
                cantidad
                >
                producto.getStock()
            ) {

                ErrorControlador
                    .mostrarAdvertencia(
                        "Stock insuficiente.\n"
                        + "Disponible: "
                        + producto.getStock()
                    );

                return;
            }

            double precio =
                producto.getPrecio();

            double sub =
                precio * cantidad;

            subtotal += sub;

            Object[] fila = {
                producto.getId(),
                producto.getNombre(),
                cantidad,
                String.format("$%.2f", precio),
                String.format("$%.2f", sub)
            };

            modelo.addRow(fila);

            actualizarTotales();

            vista
                .getTxtProducto()
                .setText("");

            vista
                .getTxtCantidad()
                .setText("");

            vista
                .getTxtProducto()
                .requestFocus();

        } catch (NumberFormatException ex) {

            ErrorControlador.mostrarAdvertencia(
                "Ingresa valores numéricos válidos"
            );

        } catch (Exception ex) {

            ErrorControlador.mostrarError(
                "Error al agregar producto",
                ex
            );
        }
    }

    public void eliminarItemSeleccionado() {

        int fila =
            vista
            .getTablaVenta()
            .getSelectedRow();

        if(fila == -1) {

            ErrorControlador.mostrarAdvertencia(
                "Selecciona un producto de "
                + "la lista para quitarlo"
            );

            return;
        }

        String subtotalStr =
            modelo
            .getValueAt(fila, 4)
            .toString()
            .replace("$", "");

        double sub =
            Double.parseDouble(subtotalStr);

        subtotal -= sub;

        modelo.removeRow(fila);

        actualizarTotales();
    }

    public void actualizarTotales() {

        double descPct = 0;

        try {

            descPct =
                Double.parseDouble(
                    vista
                    .getTxtDescuento()
                    .getText()
                    .trim()
                );

        } catch (Exception e) {

            descPct = 0;
        }

        double descuento =
            subtotal * descPct / 100;

        double montoPagar =
            subtotal - descuento;

        vista
            .getLblTotal()
            .setText(
                String.format(
                    "Subtotal: $%.2f",
                    subtotal
                )
            );

        vista
            .getLblDescuentoMuestra()
            .setText(
                String.format(
                    "Descuento (%.0f%%): -$%.2f",
                    descPct,
                    descuento
                )
            );

        vista
            .getLblMontoPagar()
            .setText(
                String.format(
                    "TOTAL A PAGAR: $%.2f",
                    montoPagar
                )
            );
    }

    public void limpiarVenta() {

        if(
            modelo.getRowCount() > 0
            &&
            !ErrorControlador.confirmar(
                "¿Deseas limpiar la venta actual?"
            )
        ) {

            return;
        }

        modelo.setRowCount(0);

        subtotal = 0;

        vista
            .getTxtDescuento()
            .setText("0");

        actualizarTotales();
    }

    public void finalizarVenta() {

        if(
            modelo.getRowCount() == 0
        ) {

            ErrorControlador.mostrarAdvertencia(
                "No hay productos en la venta"
            );

            return;
        }

        if(
            !ErrorControlador.confirmar(
                "¿Confirmar la venta?"
            )
        ) {

            return;
        }

        double descPct = 0;

        try {

            descPct =
                Double.parseDouble(
                    vista
                    .getTxtDescuento()
                    .getText()
                    .trim()
                );

        } catch (Exception e) {

            descPct = 0;
        }

        double descuento =
            subtotal * descPct / 100;

        double montoPagar =
            subtotal - descuento;

        int idVenta =
            ventaPersistencia
            .guardarVenta(
                subtotal,
                descuento,
                montoPagar
            );

        if(idVenta == -1) {

            ErrorControlador.mostrarError(
                "Error al guardar la venta",
                null
            );

            return;
        }

        for(
            int i = 0;
            i < modelo.getRowCount();
            i++
        ) {

            int idProducto =
                Integer.parseInt(
                    modelo
                    .getValueAt(i, 0)
                    .toString()
                );

            int cantidad =
                Integer.parseInt(
                    modelo
                    .getValueAt(i, 2)
                    .toString()
                );

            double precio =
                Double.parseDouble(
                    modelo
                    .getValueAt(i, 3)
                    .toString()
                    .replace("$", "")
                );

            double sub =
                Double.parseDouble(
                    modelo
                    .getValueAt(i, 4)
                    .toString()
                    .replace("$", "")
                );

            ventaPersistencia
                .guardarDetalleVenta(
                    idVenta,
                    idProducto,
                    cantidad,
                    precio,
                    sub
                );

            persistencia
                .descontarStock(
                    idProducto,
                    cantidad
                );
        }

        generarTicket(
            idVenta,
            descuento,
            montoPagar
        );

        modelo.setRowCount(0);

        subtotal = 0;

        vista
            .getTxtDescuento()
            .setText("0");

        actualizarTotales();
    }

    public void generarTicket(
        int idVenta,
        double descuento,
        double montoPagar
    ) {

        TicketVista ticket =
            new TicketVista();

        LocalDateTime ahora =
            LocalDateTime.now();

        String fecha =
            ahora.format(
                DateTimeFormatter
                .ofPattern("dd/MM/yyyy")
            );

        String hora =
            ahora.format(
                DateTimeFormatter
                .ofPattern("HH:mm:ss")
            );

        StringBuilder sb =
            new StringBuilder();

        sb.append(
            "==============================\n"
        );

        sb.append(
            "       PUNTO DE VENTA\n"
        );

        sb.append(
            "==============================\n"
        );

        sb.append(
            "Folio: #" + idVenta + "\n"
        );

        sb.append(
            "Fecha: " + fecha + "\n"
        );

        sb.append(
            "Hora:  " + hora + "\n"
        );

        sb.append(
            "------------------------------\n"
        );

        sb.append(
            String.format(
                "%-16s %4s %8s\n",
                "Producto",
                "Cant",
                "Subtotal"
            )
        );

        sb.append(
            "------------------------------\n"
        );

        for(
            int i = 0;
            i < modelo.getRowCount();
            i++
        ) {

            String cod =
                modelo
                .getValueAt(i, 0)
                .toString();

            String prod =
                modelo
                .getValueAt(i, 1)
                .toString();

            String cant =
                modelo
                .getValueAt(i, 2)
                .toString();

            String sub =
                modelo
                .getValueAt(i, 4)
                .toString();

            sb.append(
                "Cód: " + cod + "\n"
            );

            if(prod.length() > 16) {

                prod = prod.substring(0, 16);
            }

            sb.append(
                String.format(
                    "%-16s %4s %8s\n",
                    prod,
                    cant,
                    sub
                )
            );
        }

        sb.append(
            "==============================\n"
        );

        sb.append(
            String.format(
                "Subtotal:  $%8.2f\n",
                subtotal
            )
        );

        sb.append(
            String.format(
                "Descuento: -$%7.2f\n",
                descuento
            )
        );

        sb.append(
            "------------------------------\n"
        );

        sb.append(
            String.format(
                "TOTAL:     $%8.2f\n",
                montoPagar
            )
        );

        sb.append(
            "==============================\n\n"
        );

        sb.append(
            "  ¡Gracias por su compra!\n"
        );

        ticket
            .getAreaTicket()
            .setText(sb.toString());

        ticket
            .getBtnCerrar()
            .addActionListener(
                ev -> ticket.dispose()
            );

        ticket.setVisible(true);
    }
}
