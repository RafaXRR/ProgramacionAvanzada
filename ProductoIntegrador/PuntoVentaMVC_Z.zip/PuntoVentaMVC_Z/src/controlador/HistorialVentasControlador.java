package controlador;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import persistencia.VentaPersistencia;
import vista.DetalleVentaVista;
import vista.HistorialVentasVista;

public class HistorialVentasControlador {

    private HistorialVentasVista vista;

    private VentaPersistencia persistencia;

    public HistorialVentasControlador(
        HistorialVentasVista vista
    ) {

        this.vista = vista;

        persistencia =
            new VentaPersistencia();

        cargarTabla();

        eventos();
    }

    public void cargarTabla() {

        vista
            .getTablaVentas()
            .setModel(

                persistencia
                .listarVentas()
            );
    }

    public void eventos() {

        vista
            .getTablaVentas()
            .addMouseListener(

                new MouseAdapter() {

                    @Override
                    public void mouseClicked(
                        MouseEvent e
                    ) {

                        if(
                            e.getClickCount()
                            == 2
                        ) {

                            int fila =

                                vista
                                .getTablaVentas()
                                .getSelectedRow();

                            int idVenta =

                                Integer.parseInt(

                                    vista
                                    .getTablaVentas()
                                    .getValueAt(
                                        fila,
                                        0
                                    )
                                    .toString()
                                );

                            DetalleVentaVista detalle =
                                new DetalleVentaVista();

                            new DetalleVentaControlador(

                                detalle,
                                idVenta
                            );

                            detalle.setVisible(true);
                        }
                    }
                }
            );
    }
}