package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import modelo.Usuario;
import persistencia.UsuarioPersistencia;
import util.ErrorControlador;
import vista.LoginVista;
import vista.MainVista;

public class LoginControlador
    implements ActionListener {

    private LoginVista vista;

    private UsuarioPersistencia persistencia;

    public LoginControlador(
        LoginVista vista
    ) {

        this.vista = vista;

        persistencia =
            new UsuarioPersistencia();

        this.vista
            .getBtnLogin()
            .addActionListener(this);
    }

    @Override
    public void actionPerformed(
        ActionEvent e
    ) {

        String usuario =
            vista
            .getTxtUsuario()
            .getText()
            .trim();

        String password =
            String.valueOf(
                vista
                .getTxtPassword()
                .getPassword()
            );

        if(
            usuario.isEmpty()
            || password.isEmpty()
        ) {

            ErrorControlador.mostrarAdvertencia(
                "Ingresa usuario y contraseña"
            );

            return;
        }

        Usuario usuarioSistema =
            persistencia.iniciarSesion(
                usuario,
                password
            );

        if(usuarioSistema != null) {

            MainVista main =
                new MainVista();

            new MainControlador(main);

            main.setVisible(true);

            vista.dispose();

        } else {

            ErrorControlador.mostrarAdvertencia(
                "Usuario o contraseña incorrectos"
            );

            vista
                .getTxtPassword()
                .setText("");

            vista
                .getTxtUsuario()
                .requestFocus();
        }
    }
}
