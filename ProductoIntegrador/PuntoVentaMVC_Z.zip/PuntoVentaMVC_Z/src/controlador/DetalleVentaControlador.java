package controlador;

import persistencia.VentaPersistencia;
import vista.DetalleVentaVista;

public class DetalleVentaControlador {

    private DetalleVentaVista vista;

    private VentaPersistencia persistencia;

    public DetalleVentaControlador(

        DetalleVentaVista vista,
        int idVenta
    ) {

        this.vista = vista;

        persistencia =
            new VentaPersistencia();

        cargarDetalle(idVenta);
    }

    public void cargarDetalle(
        int idVenta
    ) {

        vista
            .getTablaDetalle()
            .setModel(

                persistencia
                .obtenerDetalleVenta(
                    idVenta
                )
            );
    }
}