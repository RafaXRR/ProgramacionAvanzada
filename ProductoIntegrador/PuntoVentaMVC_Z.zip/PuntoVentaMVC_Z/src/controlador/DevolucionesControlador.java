package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.swing.table.DefaultTableModel;

import persistencia.ProductoPersistencia;
import persistencia.VentaPersistencia;
import util.ErrorControlador;
import vista.DevolucionesVista;
import vista.TicketVista;

public class DevolucionesControlador
    implements ActionListener {

    private DevolucionesVista vista;

    private VentaPersistencia ventaPersistencia;

    private ProductoPersistencia
        productoPersistencia;

    public DevolucionesControlador(
        DevolucionesVista vista
    ) {

        this.vista = vista;

        ventaPersistencia =
            new VentaPersistencia();

        productoPersistencia =
            new ProductoPersistencia();

        cargarVentas();

        cargarDevoluciones();

        this.vista
            .getBtnProcesar()
            .addActionListener(this);

        this.vista
            .getBtnReimprimir()
            .addActionListener(this);

        this.vista
            .getTblVentas()
            .addMouseListener(
                new MouseAdapter() {

                    @Override
                    public void mouseClicked(
                        MouseEvent e
                    ) {

                        seleccionarVenta();
                    }
                }
            );
    }

    @Override
    public void actionPerformed(
        ActionEvent e
    ) {

        if(
            e.getSource()
            ==
            vista.getBtnProcesar()
        ) {

            procesarDevolucion();
        }

        if(
            e.getSource()
            ==
            vista.getBtnReimprimir()
        ) {

            reimprimirRecibo();
        }
    }

    public void seleccionarVenta() {

        int fila =
            vista
            .getTblVentas()
            .getSelectedRow();

        if(fila != -1) {

            String idVenta =
                vista
                .getTblVentas()
                .getValueAt(fila, 0)
                .toString();

            vista
                .getTxtIdVenta()
                .setText(idVenta);
        }
    }

    public void procesarDevolucion() {

        try {

            String txtIdV =
                vista
                .getTxtIdVenta()
                .getText()
                .trim();

            String txtIdP =
                vista
                .getTxtIdProducto()
                .getText()
                .trim();

            String txtCant =
                vista
                .getTxtCantidad()
                .getText()
                .trim();

            String motivo =
                vista
                .getTxtMotivo()
                .getText()
                .trim();

            if(
                txtIdV.isEmpty()
                || txtIdP.isEmpty()
                || txtCant.isEmpty()
                || motivo.isEmpty()
            ) {

                ErrorControlador
                    .mostrarAdvertencia(
                        "Completa todos los campos"
                    );

                return;
            }

            int idVenta =
                Integer.parseInt(txtIdV);

            int idProducto =
                Integer.parseInt(txtIdP);

            int cantidad =
                Integer.parseInt(txtCant);

            if(
                !ErrorControlador.confirmar(
                    "¿Procesar devolución de "
                    + cantidad
                    + " unidades del producto #"
                    + idProducto
                    + "?"
                )
            ) {

                return;
            }

            // Calcular monto a devolver
            double precio =
                productoPersistencia
                .obtenerProductoPorId(
                    idProducto
                ) != null
                ? productoPersistencia
                  .obtenerProductoPorId(
                      idProducto
                  ).getPrecio()
                : 0;

            double montoDevuelto =
                precio * cantidad;

            // Guardar devolución
            boolean ok =
                ventaPersistencia
                .guardarDevolucion(
                    idVenta,
                    idProducto,
                    cantidad,
                    montoDevuelto,
                    motivo
                );

            if(ok) {

                // Regresar stock
                productoPersistencia
                    .agregarStock(
                        idProducto,
                        cantidad
                    );

                ErrorControlador.mostrarExito(
                    "Devolución procesada.\n"
                    + "Monto devuelto: $"
                    + String.format(
                        "%.2f",
                        montoDevuelto
                    )
                );

                limpiarFormulario();

                cargarDevoluciones();

            } else {

                ErrorControlador.mostrarError(
                    "Error al procesar devolución",
                    null
                );
            }

        } catch (NumberFormatException ex) {

            ErrorControlador.mostrarAdvertencia(
                "Ingresa valores numéricos válidos"
            );

        } catch (Exception ex) {

            ErrorControlador.mostrarError(
                "Error inesperado",
                ex
            );
        }
    }

    public void reimprimirRecibo() {

        int fila =
            vista
            .getTblVentas()
            .getSelectedRow();

        if(fila == -1) {

            ErrorControlador.mostrarAdvertencia(
                "Selecciona una venta de la "
                + "lista para reimprimir su recibo"
            );

            return;
        }

        int idVenta =
            Integer.parseInt(
                vista
                .getTblVentas()
                .getValueAt(fila, 0)
                .toString()
            );

        String fecha =
            vista
            .getTblVentas()
            .getValueAt(fila, 1)
            .toString();

        String hora =
            vista
            .getTblVentas()
            .getValueAt(fila, 2)
            .toString();

        double total =
            Double.parseDouble(
                vista
                .getTblVentas()
                .getValueAt(fila, 3)
                .toString()
            );

        double descuento =
            Double.parseDouble(
                vista
                .getTblVentas()
                .getValueAt(fila, 4)
                .toString()
            );

        double montoPagar =
            Double.parseDouble(
                vista
                .getTblVentas()
                .getValueAt(fila, 5)
                .toString()
            );

        DefaultTableModel detalle =
            ventaPersistencia
            .obtenerDetalleVenta(idVenta);

        TicketVista ticket =
            new TicketVista();

        StringBuilder sb =
            new StringBuilder();

        sb.append(
            "==============================\n"
        );

        sb.append(
            "    PUNTO DE VENTA\n"
        );

        sb.append(
            "    *** REIMPRESIÓN ***\n"
        );

        sb.append(
            "==============================\n"
        );

        sb.append(
            "Folio: #" + idVenta + "\n"
        );

        sb.append(
            "Fecha: " + fecha + "\n"
        );

        sb.append(
            "Hora:  " + hora + "\n"
        );

        sb.append(
            "------------------------------\n"
        );

        if(detalle != null) {

            sb.append(
                String.format(
                    "%-14s %4s %8s\n",
                    "Producto",
                    "Cant",
                    "Subtotal"
                )
            );

            sb.append(
                "------------------------------\n"
            );

            for(
                int i = 0;
                i < detalle.getRowCount();
                i++
            ) {

                String cod =
                    detalle
                    .getValueAt(i, 0)
                    .toString();

                String prod =
                    detalle
                    .getValueAt(i, 1)
                    .toString();

                String cant =
                    detalle
                    .getValueAt(i, 2)
                    .toString();

                String sub =
                    "$"
                    + detalle
                    .getValueAt(i, 4)
                    .toString();

                sb.append(
                    "Cód: " + cod + "\n"
                );

                if(prod.length() > 14) {

                    prod = prod.substring(0, 14);
                }

                sb.append(
                    String.format(
                        "%-14s %4s %8s\n",
                        prod,
                        cant,
                        sub
                    )
                );
            }
        }

        sb.append(
            "==============================\n"
        );

        sb.append(
            String.format(
                "Subtotal:  $%8.2f\n",
                total
            )
        );

        sb.append(
            String.format(
                "Descuento: -$%7.2f\n",
                descuento
            )
        );

        sb.append(
            "------------------------------\n"
        );

        sb.append(
            String.format(
                "TOTAL:     $%8.2f\n",
                montoPagar
            )
        );

        sb.append(
            "==============================\n\n"
        );

        sb.append(
            "  ¡Gracias por su compra!\n"
        );

        ticket
            .getAreaTicket()
            .setText(sb.toString());

        ticket
            .getBtnCerrar()
            .addActionListener(
                ev -> ticket.dispose()
            );

        ticket.setVisible(true);
    }

    public void limpiarFormulario() {

        vista.getTxtIdVenta().setText("");

        vista.getTxtIdProducto().setText("");

        vista.getTxtCantidad().setText("");

        vista.getTxtMotivo().setText("");
    }

    public void cargarVentas() {

        vista
            .getTblVentas()
            .setModel(
                ventaPersistencia
                .listarVentas()
            );
    }

    public void cargarDevoluciones() {

        vista
            .getTblDevoluciones()
            .setModel(
                ventaPersistencia
                .listarDevoluciones()
            );
    }
}
