package controlador;

import persistencia.ProductoPersistencia;
import vista.BajoStockVista;

public class BajoStockControlador {

    private BajoStockVista vista;

    private ProductoPersistencia persistencia;

    public BajoStockControlador(
        BajoStockVista vista
    ) {

        this.vista = vista;

        persistencia =
            new ProductoPersistencia();

        cargarTabla();

        actualizarAviso();
    }

    public void cargarTabla() {

        vista
            .getTablaProductos()
            .setModel(
                persistencia
                .listarBajoStock()
            );
    }

    public void actualizarAviso() {

        int total =
            persistencia
            .totalProductosBajoStock();

        vista
            .getLblAviso()
            .setText(
                total + " producto(s) requieren "
                + "reabastecimiento urgente"
            );
    }
}
