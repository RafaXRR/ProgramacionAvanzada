package util;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.swing.JOptionPane;

public class ErrorControlador {

    private static final String ARCHIVO_LOG =
        "errores.log";

    public static void mostrarError(
        String mensaje,
        Exception e
    ) {

        JOptionPane.showMessageDialog(
            null,
            mensaje,
            "Error",
            JOptionPane.ERROR_MESSAGE
        );

        registrarEnLog(mensaje, e);
    }

    public static void mostrarAdvertencia(
        String mensaje
    ) {

        JOptionPane.showMessageDialog(
            null,
            mensaje,
            "Advertencia",
            JOptionPane.WARNING_MESSAGE
        );
    }

    public static void mostrarExito(
        String mensaje
    ) {

        JOptionPane.showMessageDialog(
            null,
            mensaje,
            "Éxito",
            JOptionPane.INFORMATION_MESSAGE
        );
    }

    public static boolean confirmar(
        String mensaje
    ) {

        int respuesta =
            JOptionPane.showConfirmDialog(
                null,
                mensaje,
                "Confirmar",
                JOptionPane.YES_NO_OPTION
            );

        return respuesta ==
            JOptionPane.YES_OPTION;
    }

    public static void registrarEnLog(
        String mensaje,
        Exception e
    ) {

        try {

            FileWriter fw =
                new FileWriter(
                    ARCHIVO_LOG,
                    true
                );

            PrintWriter pw =
                new PrintWriter(fw);

            String fecha =
                LocalDateTime
                .now()
                .format(
                    DateTimeFormatter
                    .ofPattern(
                        "yyyy-MM-dd HH:mm:ss"
                    )
                );

            pw.println(
                "[" + fecha + "] "
                + mensaje
            );

            if(e != null) {

                e.printStackTrace(pw);
            }

            pw.println();

            pw.close();
            fw.close();

        } catch (Exception ex) {

            ex.printStackTrace();
        }
    }
}
