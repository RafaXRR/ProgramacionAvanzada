package main;

import persistencia.Conexion;

public class TestConexion {

    public static void main(String[] args) {

        Conexion.conectar();
    }
}