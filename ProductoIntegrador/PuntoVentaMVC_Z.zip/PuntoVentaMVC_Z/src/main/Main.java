package main;

import controlador.LoginControlador;
import vista.LoginVista;

public class Main {

    public static void main(String[] args) {

        LoginVista vista =
            new LoginVista();

        new LoginControlador(vista);

        vista.setVisible(true);
    }
}