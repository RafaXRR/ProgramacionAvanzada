package vista;

import java.awt.Color;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

public class ProductosVista extends JFrame {

    private static final long serialVersionUID = 1L;

    private JPanel contentPane;

    private JTextField txtNombre;

    private JTextField txtPrecio;

    private JTextField txtStock;

    private JTextField txtCategoria;

    private JTextField txtBuscar;

    private JButton btnGuardar;

    private JButton btnEditar;

    private JButton btnEliminar;

    private JTable tablaProductos;

    private static final Color COLOR_AZUL =
        new Color(37, 99, 235);

    private static final Color COLOR_FONDO =
        new Color(241, 245, 249);

    private static final Color COLOR_VERDE =
        new Color(22, 163, 74);

    private static final Color COLOR_ROJO =
        new Color(220, 38, 38);

    private static final Color COLOR_AMARILLO =
        new Color(202, 138, 4);

    private static final Color COLOR_BORDE =
        new Color(203, 213, 225);

    private static final Color COLOR_GRIS =
        new Color(100, 116, 139);

    public ProductosVista() {

        setTitle("Gestion de Productos");

        setSize(1050, 650);

        setLocationRelativeTo(null);

        setDefaultCloseOperation(
            JFrame.DISPOSE_ON_CLOSE
        );

        setResizable(false);

        contentPane = new JPanel();

        contentPane.setBackground(COLOR_FONDO);

        contentPane.setLayout(null);

        setContentPane(contentPane);



        // ==================
        // HEADER
        // ==================

        JPanel panelHeader = new JPanel();

        panelHeader.setBackground(COLOR_AZUL);

        panelHeader.setLayout(null);

        panelHeader.setBounds(0, 0, 1050, 75);

        contentPane.add(panelHeader);



        JPanel barraAcento = new JPanel();

        barraAcento.setBackground(
            new Color(29, 78, 216)
        );

        barraAcento.setBounds(0, 0, 4, 75);

        panelHeader.add(barraAcento);



        JLabel lblTitulo = new JLabel(
            "Gestion de Productos"
        );

        lblTitulo.setForeground(Color.WHITE);

        lblTitulo.setFont(
            new Font("Arial Black", Font.BOLD, 22)
        );

        lblTitulo.setBounds(25, 14, 400, 30);

        panelHeader.add(lblTitulo);



        JLabel lblSub = new JLabel(
            "Alta, edicion, busqueda y eliminacion"
        );

        lblSub.setForeground(
            new Color(191, 219, 254)
        );

        lblSub.setFont(
            new Font("Arial", Font.PLAIN, 12)
        );

        lblSub.setBounds(25, 46, 400, 18);

        panelHeader.add(lblSub);



        // ==================
        // PANEL FORMULARIO
        // ==================

        JPanel panelForm = new JPanel();

        panelForm.setBackground(Color.WHITE);

        panelForm.setLayout(null);

        panelForm.setBounds(20, 90, 1010, 155);

        panelForm.setBorder(
            BorderFactory.createLineBorder(
                new Color(226, 232, 240)
            )
        );

        contentPane.add(panelForm);



        JPanel barraForm = new JPanel();

        barraForm.setBackground(COLOR_AZUL);

        barraForm.setBounds(0, 0, 4, 155);

        panelForm.add(barraForm);



        // Nombre
        JLabel lblNombre = new JLabel("Nombre");

        lblNombre.setFont(
            new Font("Arial", Font.BOLD, 12)
        );

        lblNombre.setForeground(
            new Color(30, 41, 59)
        );

        lblNombre.setBounds(20, 15, 120, 18);

        panelForm.add(lblNombre);



        txtNombre = new JTextField();

        txtNombre.setBounds(20, 36, 230, 38);

        txtNombre.setFont(
            new Font("Arial", Font.PLAIN, 14)
        );

        txtNombre.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(
                    COLOR_BORDE
                ),
                BorderFactory.createEmptyBorder(
                    5, 10, 5, 10
                )
            )
        );

        txtNombre.setBackground(
            new Color(248, 250, 252)
        );

        panelForm.add(txtNombre);



        // Precio
        JLabel lblPrecio = new JLabel("Precio");

        lblPrecio.setFont(
            new Font("Arial", Font.BOLD, 12)
        );

        lblPrecio.setForeground(
            new Color(30, 41, 59)
        );

        lblPrecio.setBounds(270, 15, 120, 18);

        panelForm.add(lblPrecio);



        txtPrecio = new JTextField();

        txtPrecio.setBounds(270, 36, 160, 38);

        txtPrecio.setFont(
            new Font("Arial", Font.PLAIN, 14)
        );

        txtPrecio.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(
                    COLOR_BORDE
                ),
                BorderFactory.createEmptyBorder(
                    5, 10, 5, 10
                )
            )
        );

        txtPrecio.setBackground(
            new Color(248, 250, 252)
        );

        panelForm.add(txtPrecio);



        // Stock
        JLabel lblStock = new JLabel("Stock");

        lblStock.setFont(
            new Font("Arial", Font.BOLD, 12)
        );

        lblStock.setForeground(
            new Color(30, 41, 59)
        );

        lblStock.setBounds(450, 15, 120, 18);

        panelForm.add(lblStock);



        txtStock = new JTextField();

        txtStock.setBounds(450, 36, 160, 38);

        txtStock.setFont(
            new Font("Arial", Font.PLAIN, 14)
        );

        txtStock.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(
                    COLOR_BORDE
                ),
                BorderFactory.createEmptyBorder(
                    5, 10, 5, 10
                )
            )
        );

        txtStock.setBackground(
            new Color(248, 250, 252)
        );

        panelForm.add(txtStock);



        // Categoria
        JLabel lblCategoria = new JLabel(
            "Categoria"
        );

        lblCategoria.setFont(
            new Font("Arial", Font.BOLD, 12)
        );

        lblCategoria.setForeground(
            new Color(30, 41, 59)
        );

        lblCategoria.setBounds(630, 15, 120, 18);

        panelForm.add(lblCategoria);



        txtCategoria = new JTextField();

        txtCategoria.setBounds(630, 36, 200, 38);

        txtCategoria.setFont(
            new Font("Arial", Font.PLAIN, 14)
        );

        txtCategoria.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(
                    COLOR_BORDE
                ),
                BorderFactory.createEmptyBorder(
                    5, 10, 5, 10
                )
            )
        );

        txtCategoria.setBackground(
            new Color(248, 250, 252)
        );

        panelForm.add(txtCategoria);



        // Botones
        btnGuardar = crearBoton(
            "Guardar",
            COLOR_AZUL,
            20, 95, 160, 42
        );

        panelForm.add(btnGuardar);



        btnEditar = crearBoton(
            "Editar",
            COLOR_AMARILLO,
            195, 95, 160, 42
        );

        panelForm.add(btnEditar);



        btnEliminar = crearBoton(
            "Eliminar",
            COLOR_ROJO,
            370, 95, 160, 42
        );

        panelForm.add(btnEliminar);



        // Buscar
        JLabel lblBuscar = new JLabel("Buscar");

        lblBuscar.setFont(
            new Font("Arial", Font.BOLD, 12)
        );

        lblBuscar.setForeground(COLOR_GRIS);

        lblBuscar.setBounds(630, 88, 100, 18);

        panelForm.add(lblBuscar);



        txtBuscar = new JTextField();

        txtBuscar.setBounds(630, 108, 200, 38);

        txtBuscar.setFont(
            new Font("Arial", Font.PLAIN, 14)
        );

        txtBuscar.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(
                    COLOR_BORDE
                ),
                BorderFactory.createEmptyBorder(
                    5, 10, 5, 10
                )
            )
        );

        txtBuscar.setBackground(
            new Color(248, 250, 252)
        );

        panelForm.add(txtBuscar);



        // ==================
        // TABLA
        // ==================

        JPanel panelTabla = new JPanel();

        panelTabla.setBackground(Color.WHITE);

        panelTabla.setLayout(null);

        panelTabla.setBounds(20, 260, 1010, 340);

        panelTabla.setBorder(
            BorderFactory.createLineBorder(
                new Color(226, 232, 240)
            )
        );

        contentPane.add(panelTabla);



        JPanel barraTabla = new JPanel();

        barraTabla.setBackground(COLOR_VERDE);

        barraTabla.setBounds(0, 0, 4, 340);

        panelTabla.add(barraTabla);



        JLabel lblTabTit = new JLabel(
            "Listado de Productos"
        );

        lblTabTit.setFont(
            new Font("Arial", Font.BOLD, 13)
        );

        lblTabTit.setForeground(
            new Color(30, 41, 59)
        );

        lblTabTit.setBounds(15, 12, 300, 20);

        panelTabla.add(lblTabTit);



        JPanel lineaTabla = new JPanel();

        lineaTabla.setBackground(
            new Color(226, 232, 240)
        );

        lineaTabla.setBounds(15, 36, 985, 1);

        panelTabla.add(lineaTabla);



        JScrollPane scrollPane = new JScrollPane();

        scrollPane.setBounds(8, 42, 993, 288);

        scrollPane.setBorder(null);

        panelTabla.add(scrollPane);



        tablaProductos = new JTable() {

            private static final long
                serialVersionUID = 1L;

            @Override
            public boolean isCellEditable(
                int row,
                int column
            ) {
                return false;
            }
        };

        tablaProductos.setRowHeight(30);

        tablaProductos.setFont(
            new Font("Arial", Font.PLAIN, 13)
        );

        tablaProductos.getTableHeader().setFont(
            new Font("Arial", Font.BOLD, 13)
        );

        tablaProductos.getTableHeader()
            .setBackground(
                new Color(241, 245, 249)
            );

        tablaProductos.setGridColor(
            new Color(241, 245, 249)
        );

        tablaProductos.setSelectionBackground(
            new Color(219, 234, 254)
        );

        tablaProductos.setSelectionForeground(
            new Color(30, 64, 175)
        );

        scrollPane.setViewportView(tablaProductos);
    }

    private JButton crearBoton(
        String texto,
        Color color,
        int x,
        int y,
        int w,
        int h
    ) {

        JButton btn = new JButton(texto);

        btn.setBounds(x, y, w, h);

        btn.setBackground(color);

        btn.setForeground(Color.WHITE);

        btn.setFont(
            new Font("Arial", Font.BOLD, 13)
        );

        btn.setFocusPainted(false);

        btn.setBorderPainted(false);

        btn.setCursor(
            new java.awt.Cursor(
                java.awt.Cursor.HAND_CURSOR
            )
        );

        return btn;
    }

    public JTextField getTxtNombre() {
        return txtNombre;
    }

    public JTextField getTxtPrecio() {
        return txtPrecio;
    }

    public JTextField getTxtStock() {
        return txtStock;
    }

    public JTextField getTxtCategoria() {
        return txtCategoria;
    }

    public JTextField getTxtBuscar() {
        return txtBuscar;
    }

    public JButton getBtnGuardar() {
        return btnGuardar;
    }

    public JButton getBtnEditar() {
        return btnEditar;
    }

    public JButton getBtnEliminar() {
        return btnEliminar;
    }

    public JTable getTablaProductos() {
        return tablaProductos;
    }
}