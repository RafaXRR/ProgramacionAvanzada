package vista;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class TicketVista extends JFrame {

    private static final long serialVersionUID = 1L;

    private JTextArea areaTicket;

    private JButton btnCerrar;

    public TicketVista() {

        setTitle("Recibo de Compra");

        setSize(420, 650);

        setLocationRelativeTo(null);

        setDefaultCloseOperation(
            JFrame.DISPOSE_ON_CLOSE
        );

        setLayout(null);

        getContentPane().setBackground(
            Color.WHITE
        );



        JPanel panelHeader = new JPanel();

        panelHeader.setBackground(
            new Color(22, 163, 74)
        );

        panelHeader.setBounds(0, 0, 420, 50);

        panelHeader.setLayout(null);

        add(panelHeader);



        JScrollPane scroll = new JScrollPane();

        scroll.setBounds(10, 60, 385, 520);

        add(scroll);



        areaTicket = new JTextArea();

        areaTicket.setEditable(false);

        areaTicket.setFont(
            new Font("Monospaced", Font.PLAIN, 14)
        );

        areaTicket.setBackground(Color.WHITE);

        areaTicket.setMargin(
            new java.awt.Insets(10, 10, 10, 10)
        );

        scroll.setViewportView(areaTicket);



        btnCerrar = new JButton("Cerrar");

        btnCerrar.setBounds(140, 590, 120, 35);

        btnCerrar.setBackground(
            new Color(100, 116, 139)
        );

        btnCerrar.setForeground(Color.WHITE);

        btnCerrar.setFont(
            new Font("Arial", Font.BOLD, 13)
        );

        btnCerrar.setFocusPainted(false);

        btnCerrar.setBorderPainted(false);

        add(btnCerrar);
    }

    public JTextArea getAreaTicket() {
        return areaTicket;
    }

    public JButton getBtnCerrar() {
        return btnCerrar;
    }
}
