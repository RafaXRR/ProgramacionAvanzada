package vista;

import java.awt.Color;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class MainVista extends JFrame {

    private static final long serialVersionUID = 1L;

    private JPanel contentPane;

    private JButton btnProductos;

    private JButton btnVentas;

    private JButton btnHistorial;

    private JButton btnAlmacen;

    private JButton btnReportes;

    private JButton btnDevoluciones;

    private JButton btnBajoStock;

    private JLabel lblTotalProductos;

    private JLabel lblTotalVentas;

    private JLabel lblIngresos;

    private JLabel lblBajoStock;

    private static final Color COLOR_MENU =
        new Color(15, 23, 42);

    private static final Color COLOR_ACENTO =
        new Color(37, 99, 235);

    private static final Color COLOR_FONDO =
        new Color(241, 245, 249);

    private static final Color COLOR_VERDE =
        new Color(22, 163, 74);

    private static final Color COLOR_NARANJA =
        new Color(234, 88, 12);

    private static final Color COLOR_AMARILLO =
        new Color(202, 138, 4);

    public MainVista() {

        setTitle("Sistema Punto de Venta");

        setDefaultCloseOperation(
            JFrame.EXIT_ON_CLOSE
        );

        setSize(1200, 700);

        setLocationRelativeTo(null);

        setResizable(false);

        contentPane = new JPanel();

        contentPane.setBackground(COLOR_FONDO);

        contentPane.setLayout(null);

        setContentPane(contentPane);



        // ==================
        // MENU LATERAL
        // ==================

        JPanel panelMenu = new JPanel();

        panelMenu.setBackground(COLOR_MENU);

        panelMenu.setLayout(null);

        panelMenu.setBounds(0, 0, 240, 700);

        contentPane.add(panelMenu);



        // Barra acento izquierda
        JPanel barraAcento = new JPanel();

        barraAcento.setBackground(COLOR_ACENTO);

        barraAcento.setBounds(0, 0, 4, 700);

        panelMenu.add(barraAcento);



        JLabel lblSistema = new JLabel("SISTEMA");

        lblSistema.setForeground(
            new Color(96, 165, 250)
        );

        lblSistema.setFont(
            new Font("Arial", Font.BOLD, 10)
        );

        lblSistema.setBounds(20, 22, 200, 16);

        panelMenu.add(lblSistema);



        JLabel lblLogo = new JLabel(
            "Punto de Venta"
        );

        lblLogo.setForeground(Color.WHITE);

        lblLogo.setFont(
            new Font("Arial Black", Font.BOLD, 15)
        );

        lblLogo.setBounds(20, 38, 210, 26);

        panelMenu.add(lblLogo);



        JPanel sep1 = new JPanel();

        sep1.setBackground(
            new Color(44, 62, 80)
        );

        sep1.setBounds(20, 78, 195, 1);

        panelMenu.add(sep1);



        JLabel lblNav = new JLabel("NAVEGACIÓN");

        lblNav.setForeground(
            new Color(100, 116, 139)
        );

        lblNav.setFont(
            new Font("Arial", Font.BOLD, 10)
        );

        lblNav.setBounds(20, 95, 200, 18);

        panelMenu.add(lblNav);



        btnProductos = crearBotonMenu(
            "  Productos",
            panelMenu,
            120
        );

        btnVentas = crearBotonMenu(
            "  Ventas",
            panelMenu,
            168
        );

        btnHistorial = crearBotonMenu(
            "  Historial",
            panelMenu,
            216
        );

        btnAlmacen = crearBotonMenu(
            "  Almacen",
            panelMenu,
            264
        );



        JPanel sep2 = new JPanel();

        sep2.setBackground(
            new Color(44, 62, 80)
        );

        sep2.setBounds(20, 318, 195, 1);

        panelMenu.add(sep2);



        JLabel lblAnalisis = new JLabel(
            "ANÁLISIS"
        );

        lblAnalisis.setForeground(
            new Color(100, 116, 139)
        );

        lblAnalisis.setFont(
            new Font("Arial", Font.BOLD, 10)
        );

        lblAnalisis.setBounds(20, 330, 200, 18);

        panelMenu.add(lblAnalisis);



        btnReportes = crearBotonMenu(
            "  Reportes",
            panelMenu,
            355
        );

        btnDevoluciones = crearBotonMenu(
            "  Devoluciones",
            panelMenu,
            403
        );

        btnBajoStock = crearBotonMenu(
            "  Bajo Stock",
            panelMenu,
            451
        );

        btnBajoStock.setForeground(
            new Color(251, 191, 36)
        );



        JLabel lblVersion = new JLabel(
            "v1.0  -  2026"
        );

        lblVersion.setForeground(
            new Color(71, 85, 105)
        );

        lblVersion.setFont(
            new Font("Arial", Font.PLAIN, 10)
        );

        lblVersion.setBounds(20, 665, 200, 16);

        panelMenu.add(lblVersion);



        // ==================
        // CONTENIDO
        // ==================

        JPanel panelContenido = new JPanel();

        panelContenido.setBackground(COLOR_FONDO);

        panelContenido.setLayout(null);

        panelContenido.setBounds(
            240, 0, 960, 700
        );

        contentPane.add(panelContenido);



        // Header
        JPanel panelHeader = new JPanel();

        panelHeader.setBackground(Color.WHITE);

        panelHeader.setLayout(null);

        panelHeader.setBounds(0, 0, 960, 80);

        panelContenido.add(panelHeader);



        JLabel lblTituloPag = new JLabel(
            "Dashboard"
        );

        lblTituloPag.setFont(
            new Font("Arial Black", Font.BOLD, 24)
        );

        lblTituloPag.setForeground(
            new Color(15, 23, 42)
        );

        lblTituloPag.setBounds(35, 14, 300, 32);

        panelHeader.add(lblTituloPag);



        JLabel lblSub = new JLabel(
            "Resumen general del sistema"
        );

        lblSub.setFont(
            new Font("Arial", Font.PLAIN, 13)
        );

        lblSub.setForeground(
            new Color(100, 116, 139)
        );

        lblSub.setBounds(35, 46, 400, 20);

        panelHeader.add(lblSub);



        JPanel lineaHeader = new JPanel();

        lineaHeader.setBackground(
            new Color(226, 232, 240)
        );

        lineaHeader.setBounds(0, 79, 960, 1);

        panelHeader.add(lineaHeader);



        // ==================
        // TARJETAS
        // ==================

        JPanel cardProductos = crearCard(
            panelContenido,
            35, 105, 205, 115,
            COLOR_ACENTO
        );

        lblTotalProductos = new JLabel("0");

        lblTotalProductos.setFont(
            new Font("Arial Black", Font.BOLD, 42)
        );

        lblTotalProductos.setForeground(
            Color.WHITE
        );

        lblTotalProductos.setBounds(
            15, 10, 175, 55
        );

        cardProductos.add(lblTotalProductos);

        JPanel barraCardP = new JPanel();

        barraCardP.setBackground(
            new Color(0, 0, 0, 50)
        );

        barraCardP.setLayout(null);

        barraCardP.setBounds(0, 88, 205, 27);

        cardProductos.add(barraCardP);

        JLabel etqP = new JLabel("Productos");

        etqP.setFont(
            new Font("Arial", Font.BOLD, 11)
        );

        etqP.setForeground(
            new Color(219, 234, 254)
        );

        etqP.setBounds(10, 5, 180, 17);

        barraCardP.add(etqP);



        JPanel cardVentas = crearCard(
            panelContenido,
            255, 105, 205, 115,
            COLOR_VERDE
        );

        lblTotalVentas = new JLabel("0");

        lblTotalVentas.setFont(
            new Font("Arial Black", Font.BOLD, 42)
        );

        lblTotalVentas.setForeground(Color.WHITE);

        lblTotalVentas.setBounds(
            15, 10, 175, 55
        );

        cardVentas.add(lblTotalVentas);

        JPanel barraCardV = new JPanel();

        barraCardV.setBackground(
            new Color(0, 0, 0, 50)
        );

        barraCardV.setLayout(null);

        barraCardV.setBounds(0, 88, 205, 27);

        cardVentas.add(barraCardV);

        JLabel etqV = new JLabel(
            "Ventas realizadas"
        );

        etqV.setFont(
            new Font("Arial", Font.BOLD, 11)
        );

        etqV.setForeground(
            new Color(220, 252, 231)
        );

        etqV.setBounds(10, 5, 180, 17);

        barraCardV.add(etqV);



        JPanel cardIngresos = crearCard(
            panelContenido,
            475, 105, 205, 115,
            COLOR_NARANJA
        );

        lblIngresos = new JLabel("$0.00");

        lblIngresos.setFont(
            new Font("Arial Black", Font.BOLD, 28)
        );

        lblIngresos.setForeground(Color.WHITE);

        lblIngresos.setBounds(15, 16, 185, 50);

        cardIngresos.add(lblIngresos);

        JPanel barraCardI = new JPanel();

        barraCardI.setBackground(
            new Color(0, 0, 0, 50)
        );

        barraCardI.setLayout(null);

        barraCardI.setBounds(0, 88, 205, 27);

        cardIngresos.add(barraCardI);

        JLabel etqI = new JLabel("Ingresos totales");

        etqI.setFont(
            new Font("Arial", Font.BOLD, 11)
        );

        etqI.setForeground(
            new Color(255, 237, 213)
        );

        etqI.setBounds(10, 5, 180, 17);

        barraCardI.add(etqI);



        JPanel cardStock = crearCard(
            panelContenido,
            695, 105, 205, 115,
            COLOR_AMARILLO
        );

        lblBajoStock = new JLabel("0");

        lblBajoStock.setFont(
            new Font("Arial Black", Font.BOLD, 42)
        );

        lblBajoStock.setForeground(Color.WHITE);

        lblBajoStock.setBounds(
            15, 10, 175, 55
        );

        cardStock.add(lblBajoStock);

        JPanel barraCardS = new JPanel();

        barraCardS.setBackground(
            new Color(0, 0, 0, 50)
        );

        barraCardS.setLayout(null);

        barraCardS.setBounds(0, 88, 205, 27);

        cardStock.add(barraCardS);

        JLabel etqS = new JLabel("Bajo stock");

        etqS.setFont(
            new Font("Arial", Font.BOLD, 11)
        );

        etqS.setForeground(
            new Color(254, 243, 199)
        );

        etqS.setBounds(10, 5, 150, 17);

        barraCardS.add(etqS);



        // ==================
        // PANEL BIENVENIDA
        // ==================

        JPanel panelBienvenida = new JPanel();

        panelBienvenida.setBackground(Color.WHITE);

        panelBienvenida.setLayout(null);

        panelBienvenida.setBounds(
            35, 248, 430, 408
        );

        panelBienvenida.setBorder(
            BorderFactory.createLineBorder(
                new Color(226, 232, 240)
            )
        );

        panelContenido.add(panelBienvenida);



        JPanel barraWelcome = new JPanel();

        barraWelcome.setBackground(COLOR_ACENTO);

        barraWelcome.setBounds(0, 0, 4, 408);

        panelBienvenida.add(barraWelcome);



        JLabel lblBienvenido = new JLabel(
            "Bienvenido al Sistema"
        );

        lblBienvenido.setFont(
            new Font(
                "Arial Black", Font.BOLD, 17
            )
        );

        lblBienvenido.setForeground(
            new Color(15, 23, 42)
        );

        lblBienvenido.setBounds(22, 25, 390, 26);

        panelBienvenida.add(lblBienvenido);



        JLabel lblDescW = new JLabel(
            "Selecciona un modulo del menu lateral"
        );

        lblDescW.setFont(
            new Font("Arial", Font.PLAIN, 12)
        );

        lblDescW.setForeground(
            new Color(100, 116, 139)
        );

        lblDescW.setBounds(22, 54, 390, 18);

        panelBienvenida.add(lblDescW);



        JPanel sepW = new JPanel();

        sepW.setBackground(
            new Color(226, 232, 240)
        );

        sepW.setBounds(22, 82, 385, 1);

        panelBienvenida.add(sepW);



        String[][] modulos = {
            {"Productos",
                "Alta, edicion y busqueda"},
            {"Ventas",
                "Registrar ventas y ticket"},
            {"Historial",
                "Consultar ventas anteriores"},
            {"Almacen",
                "Stock y cambio de precios"},
            {"Reportes",
                "Filtros y exportar a Excel/PDF"},
            {"Devoluciones",
                "Retornos y reimprimir recibos"},
            {"Bajo Stock",
                "Productos por reabastecer"},
        };

        Color[] colores = {
            COLOR_ACENTO,
            COLOR_VERDE,
            new Color(100, 116, 139),
            COLOR_NARANJA,
            new Color(124, 58, 237),
            new Color(220, 38, 38),
            COLOR_AMARILLO
        };

        for(int i = 0; i < modulos.length; i++) {

            JPanel dot = new JPanel();

            dot.setBackground(colores[i]);

            dot.setBounds(
                22, 100 + (i * 42), 4, 22
            );

            panelBienvenida.add(dot);

            JLabel lblMod = new JLabel(
                modulos[i][0]
            );

            lblMod.setFont(
                new Font("Arial", Font.BOLD, 13)
            );

            lblMod.setForeground(
                new Color(30, 41, 59)
            );

            lblMod.setBounds(
                34, 98 + (i * 42), 180, 20
            );

            panelBienvenida.add(lblMod);

            JLabel lblDescMod = new JLabel(
                modulos[i][1]
            );

            lblDescMod.setFont(
                new Font("Arial", Font.PLAIN, 11)
            );

            lblDescMod.setForeground(
                new Color(148, 163, 184)
            );

            lblDescMod.setBounds(
                34, 116 + (i * 42), 370, 15
            );

            panelBienvenida.add(lblDescMod);
        }



        // ==================
        // PANEL INFO
        // ==================

        JPanel panelInfo = new JPanel();

        panelInfo.setBackground(Color.WHITE);

        panelInfo.setLayout(null);

        panelInfo.setBounds(490, 248, 415, 408);

        panelInfo.setBorder(
            BorderFactory.createLineBorder(
                new Color(226, 232, 240)
            )
        );

        panelContenido.add(panelInfo);



        JPanel barraInfo = new JPanel();

        barraInfo.setBackground(COLOR_VERDE);

        barraInfo.setBounds(0, 0, 4, 408);

        panelInfo.add(barraInfo);



        JLabel lblInfoTit = new JLabel(
            "Informacion del Sistema"
        );

        lblInfoTit.setFont(
            new Font("Arial Black", Font.BOLD, 16)
        );

        lblInfoTit.setForeground(
            new Color(15, 23, 42)
        );

        lblInfoTit.setBounds(22, 25, 370, 26);

        panelInfo.add(lblInfoTit);



        JPanel sepInfo = new JPanel();

        sepInfo.setBackground(
            new Color(226, 232, 240)
        );

        sepInfo.setBounds(22, 62, 370, 1);

        panelInfo.add(sepInfo);



        String[][] info = {
            {"Sistema",       "Punto de Venta v1.0"},
            {"Base de datos", "SQL Server Express"},
            {"Tecnologia",    "Java Swing - MVC"},
            {"Año",           "2026"},
        };

        for(int i = 0; i < info.length; i++) {

            JLabel lblKey = new JLabel(
                info[i][0]
            );

            lblKey.setFont(
                new Font("Arial", Font.BOLD, 12)
            );

            lblKey.setForeground(
                new Color(100, 116, 139)
            );

            lblKey.setBounds(
                22, 80 + (i * 44), 180, 18
            );

            panelInfo.add(lblKey);

            JLabel lblVal = new JLabel(
                info[i][1]
            );

            lblVal.setFont(
                new Font("Arial", Font.PLAIN, 14)
            );

            lblVal.setForeground(
                new Color(15, 23, 42)
            );

            lblVal.setBounds(
                22, 98 + (i * 44), 370, 20
            );

            panelInfo.add(lblVal);
        }
    }

    private JButton crearBotonMenu(
        String texto,
        JPanel panel,
        int y
    ) {

        JButton btn = new JButton(texto);

        btn.setBounds(4, y, 236, 42);

        btn.setBackground(COLOR_MENU);

        btn.setForeground(
            new Color(148, 163, 184)
        );

        btn.setFont(
            new Font("Arial", Font.PLAIN, 13)
        );

        btn.setBorderPainted(false);

        btn.setFocusPainted(false);

        btn.setCursor(
            new java.awt.Cursor(
                java.awt.Cursor.HAND_CURSOR
            )
        );

        btn.setHorizontalAlignment(
            SwingConstants.LEFT
        );

        panel.add(btn);

        return btn;
    }

    private JPanel crearCard(
        JPanel padre,
        int x,
        int y,
        int w,
        int h,
        Color color
    ) {

        JPanel card = new JPanel();

        card.setBackground(color);

        card.setBounds(x, y, w, h);

        card.setLayout(null);

        padre.add(card);

        return card;
    }

    public JButton getBtnProductos() {
        return btnProductos;
    }

    public JButton getBtnVentas() {
        return btnVentas;
    }

    public JButton getBtnHistorial() {
        return btnHistorial;
    }

    public JButton getBtnAlmacen() {
        return btnAlmacen;
    }

    public JButton getBtnReportes() {
        return btnReportes;
    }

    public JButton getBtnDevoluciones() {
        return btnDevoluciones;
    }

    public JButton getBtnBajoStock() {
        return btnBajoStock;
    }

    public JLabel getLblTotalProductos() {
        return lblTotalProductos;
    }

    public JLabel getLblTotalVentas() {
        return lblTotalVentas;
    }

    public JLabel getLblIngresos() {
        return lblIngresos;
    }

    public JLabel getLblBajoStock() {
        return lblBajoStock;
    }
}