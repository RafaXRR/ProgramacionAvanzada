package vista;

import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class DetalleVentaVista
    extends JFrame {

    private static final long serialVersionUID = 1L;

    private JTable tablaDetalle;

    public DetalleVentaVista() {

        setTitle(
            "Detalle de Venta"
        );

        setSize(800, 500);

        setLocationRelativeTo(null);

        setDefaultCloseOperation(
            JFrame.DISPOSE_ON_CLOSE
        );

        setLayout(null);



        JLabel titulo = new JLabel(
            "Detalle de Venta"
        );

        titulo.setFont(
            new Font(
                "Arial",
                Font.BOLD,
                26
            )
        );

        titulo.setBounds(
            30,
            20,
            400,
            40
        );

        add(titulo);



        JScrollPane scroll =
            new JScrollPane();

        scroll.setBounds(
            30,
            100,
            720,
            300
        );

        add(scroll);



        tablaDetalle = new JTable() {

            private static final long
                serialVersionUID = 1L;

            @Override
            public boolean isCellEditable(

                int row,
                int column
            ) {

                return false;
            }
        };

        scroll.setViewportView(
            tablaDetalle
        );
    }

    public JTable getTablaDetalle() {

        return tablaDetalle;
    }
}