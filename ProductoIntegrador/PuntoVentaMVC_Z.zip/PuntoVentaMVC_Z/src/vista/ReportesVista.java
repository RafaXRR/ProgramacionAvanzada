package vista;

import java.awt.Color;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import java.awt.Cursor;

public class ReportesVista extends JFrame {

    private static final long serialVersionUID = 1L;

    private JPanel contentPane;

    private JTextField txtFechaInicio;

    private JTextField txtFechaFin;

    private JButton btnBuscar;

    private JButton btnTodas;

    private JButton btnExcel;

    private JTable tablaReporte;

    private JLabel lblResumen;
    
    private JButton btnPdf;

    private static final Color COLOR_FONDO =
        new Color(241, 245, 249);

    private static final Color COLOR_HEADER =
        new Color(124, 58, 237);

    private static final Color COLOR_AZUL =
        new Color(37, 99, 235);

    private static final Color COLOR_VERDE =
        new Color(22, 163, 74);

    private static final Color COLOR_NARANJA =
        new Color(234, 88, 12);

    private static final Color COLOR_GRIS =
        new Color(100, 116, 139);

    private static final Color COLOR_BORDE =
        new Color(203, 213, 225);

    public ReportesVista() {

        setTitle("Reportes de Ventas");

        setSize(1000, 630);

        setLocationRelativeTo(null);

        setDefaultCloseOperation(
            JFrame.DISPOSE_ON_CLOSE
        );

        setResizable(false);

        contentPane = new JPanel();

        contentPane.setBackground(COLOR_FONDO);

        contentPane.setLayout(null);

        setContentPane(contentPane);



        // ==================
        // HEADER
        // ==================

        JPanel panelHeader = new JPanel();

        panelHeader.setBackground(COLOR_HEADER);

        panelHeader.setLayout(null);

        panelHeader.setBounds(0, 0, 1000, 75);

        contentPane.add(panelHeader);



        JPanel barraAcento = new JPanel();

        barraAcento.setBackground(
            new Color(91, 33, 182)
        );

        barraAcento.setBounds(0, 0, 4, 75);

        panelHeader.add(barraAcento);



        JLabel lblTitulo = new JLabel(
            "Reportes de Ventas"
        );

        lblTitulo.setForeground(Color.WHITE);

        lblTitulo.setFont(
            new Font("Arial Black", Font.BOLD, 22)
        );

        lblTitulo.setBounds(25, 14, 400, 30);

        panelHeader.add(lblTitulo);



        JLabel lblSub = new JLabel(
            "Filtra por fecha y exporta a Excel"
        );

        lblSub.setForeground(
            new Color(221, 214, 254)
        );

        lblSub.setFont(
            new Font("Arial", Font.PLAIN, 12)
        );

        lblSub.setBounds(25, 46, 400, 18);

        panelHeader.add(lblSub);



        // ==================
        // PANEL FILTROS
        // ==================

        JPanel panelFiltros = new JPanel();

        panelFiltros.setBackground(Color.WHITE);

        panelFiltros.setLayout(null);

        panelFiltros.setBounds(20, 90, 955, 110);

        panelFiltros.setBorder(
            BorderFactory.createLineBorder(
                new Color(226, 232, 240)
            )
        );

        contentPane.add(panelFiltros);



        JPanel barraFiltros = new JPanel();

        barraFiltros.setBackground(COLOR_HEADER);

        barraFiltros.setBounds(0, 0, 4, 110);

        panelFiltros.add(barraFiltros);



        JLabel lblFiltroTit = new JLabel(
            "Filtrar por rango de fechas"
        );

        lblFiltroTit.setFont(
            new Font("Arial", Font.BOLD, 13)
        );

        lblFiltroTit.setForeground(
            new Color(30, 41, 59)
        );

        lblFiltroTit.setBounds(15, 10, 300, 20);

        panelFiltros.add(lblFiltroTit);



        JPanel lineaFiltros = new JPanel();

        lineaFiltros.setBackground(
            new Color(226, 232, 240)
        );

        lineaFiltros.setBounds(15, 32, 925, 1);

        panelFiltros.add(lineaFiltros);



        JLabel lblFechaI = new JLabel(
            "Fecha Inicio  (yyyy-MM-dd)"
        );

        lblFechaI.setFont(
            new Font("Arial", Font.BOLD, 12)
        );

        lblFechaI.setForeground(
            new Color(30, 41, 59)
        );

        lblFechaI.setBounds(15, 40, 200, 18);

        panelFiltros.add(lblFechaI);



        txtFechaInicio = new JTextField();

        txtFechaInicio.setBounds(15, 60, 180, 38);

        txtFechaInicio.setFont(
            new Font("Arial", Font.PLAIN, 14)
        );

        txtFechaInicio.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(
                    COLOR_BORDE
                ),
                BorderFactory.createEmptyBorder(
                    5, 10, 5, 10
                )
            )
        );

        txtFechaInicio.setBackground(
            new Color(248, 250, 252)
        );

        panelFiltros.add(txtFechaInicio);



        JLabel lblFechaF = new JLabel(
            "Fecha Fin  (yyyy-MM-dd)"
        );

        lblFechaF.setFont(
            new Font("Arial", Font.BOLD, 12)
        );

        lblFechaF.setForeground(
            new Color(30, 41, 59)
        );

        lblFechaF.setBounds(210, 40, 200, 18);

        panelFiltros.add(lblFechaF);



        txtFechaFin = new JTextField();

        txtFechaFin.setBounds(210, 60, 180, 38);

        txtFechaFin.setFont(
            new Font("Arial", Font.PLAIN, 14)
        );

        txtFechaFin.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(
                    COLOR_BORDE
                ),
                BorderFactory.createEmptyBorder(
                    5, 10, 5, 10
                )
            )
        );

        txtFechaFin.setBackground(
            new Color(248, 250, 252)
        );

        panelFiltros.add(txtFechaFin);



        btnBuscar = new JButton("Buscar");

        btnBuscar.setBounds(405, 60, 120, 38);

        btnBuscar.setBackground(COLOR_AZUL);

        btnBuscar.setForeground(Color.WHITE);

        btnBuscar.setFont(
            new Font("Arial", Font.BOLD, 13)
        );

        btnBuscar.setFocusPainted(false);

        btnBuscar.setBorderPainted(false);

        btnBuscar.setCursor(
            new java.awt.Cursor(
                java.awt.Cursor.HAND_CURSOR
            )
        );

        panelFiltros.add(btnBuscar);



        btnTodas = new JButton("Ver Todas");

        btnTodas.setBounds(538, 60, 120, 38);

        btnTodas.setBackground(COLOR_GRIS);

        btnTodas.setForeground(Color.WHITE);

        btnTodas.setFont(
            new Font("Arial", Font.BOLD, 13)
        );

        btnTodas.setFocusPainted(false);

        btnTodas.setBorderPainted(false);

        btnTodas.setCursor(
            new java.awt.Cursor(
                java.awt.Cursor.HAND_CURSOR
            )
        );

        panelFiltros.add(btnTodas);



        btnExcel = new JButton("Excel");

        btnExcel.setBounds(730, 60, 100, 38);

        btnExcel.setBackground(COLOR_VERDE);

        btnExcel.setForeground(Color.WHITE);

        btnExcel.setFont(
            new Font("Arial", Font.BOLD, 13)
        );

        btnExcel.setFocusPainted(false);

        btnExcel.setBorderPainted(false);

        btnExcel.setCursor(
            new java.awt.Cursor(
                java.awt.Cursor.HAND_CURSOR
            )
        );

        panelFiltros.add(btnExcel);
        
        btnPdf = new JButton("PDF");
        btnPdf.setForeground(Color.WHITE);
        btnPdf.setFont(new Font("Arial", Font.BOLD, 13));
        btnPdf.setFocusPainted(false);
        btnPdf.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnPdf.setBorderPainted(false);
        btnPdf.setBackground(new Color(255, 0, 0));
        btnPdf.setBounds(840, 60, 100, 38);
        panelFiltros.add(btnPdf);



        // ==================
        // TABLA
        // ==================

        JPanel panelTabla = new JPanel();

        panelTabla.setBackground(Color.WHITE);

        panelTabla.setLayout(null);

        panelTabla.setBounds(20, 215, 955, 375);

        panelTabla.setBorder(
            BorderFactory.createLineBorder(
                new Color(226, 232, 240)
            )
        );

        contentPane.add(panelTabla);



        JPanel barraTabla = new JPanel();

        barraTabla.setBackground(COLOR_HEADER);

        barraTabla.setBounds(0, 0, 4, 375);

        panelTabla.add(barraTabla);



        lblResumen = new JLabel(
            "Resultados: 0 ventas"
        );

        lblResumen.setFont(
            new Font("Arial", Font.BOLD, 13)
        );

        lblResumen.setForeground(COLOR_NARANJA);

        lblResumen.setBounds(15, 10, 500, 20);

        panelTabla.add(lblResumen);



        JPanel lineaTabla = new JPanel();

        lineaTabla.setBackground(
            new Color(226, 232, 240)
        );

        lineaTabla.setBounds(15, 34, 930, 1);

        panelTabla.add(lineaTabla);



        JScrollPane scroll = new JScrollPane();

        scroll.setBounds(8, 40, 938, 325);

        scroll.setBorder(null);

        panelTabla.add(scroll);



        tablaReporte = new JTable() {

            private static final long
                serialVersionUID = 1L;

            @Override
            public boolean isCellEditable(
                int row,
                int column
            ) {
                return false;
            }
        };

        tablaReporte.setRowHeight(30);

        tablaReporte.setFont(
            new Font("Arial", Font.PLAIN, 13)
        );

        tablaReporte.getTableHeader().setFont(
            new Font("Arial", Font.BOLD, 13)
        );

        tablaReporte.getTableHeader()
            .setBackground(
                new Color(241, 245, 249)
            );

        tablaReporte.setGridColor(
            new Color(241, 245, 249)
        );

        tablaReporte.setSelectionBackground(
            new Color(237, 233, 254)
        );

        tablaReporte.setSelectionForeground(
            new Color(91, 33, 182)
        );

        scroll.setViewportView(tablaReporte);
    }

    public JTextField getTxtFechaInicio() {
        return txtFechaInicio;
    }

    public JTextField getTxtFechaFin() {
        return txtFechaFin;
    }

    public JButton getBtnBuscar() {
        return btnBuscar;
    }

    public JButton getBtnTodas() {
        return btnTodas;
    }

    public JButton getBtnExcel() {
        return btnExcel;
    }

    public JTable getTablaReporte() {
        return tablaReporte;
    }

    public JLabel getLblResumen() {
        return lblResumen;
    }
    
    public JButton getBtnPdf() {

        return btnPdf;
    }
}