package vista;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class BajoStockVista extends JFrame {

    private static final long serialVersionUID = 1L;

    private JTable tablaProductos;

    private JLabel lblAviso;

    public BajoStockVista() {

        setTitle(
            "Reporte de Productos Bajo Stock"
        );

        setSize(850, 530);

        setLocationRelativeTo(null);

        setDefaultCloseOperation(
            JFrame.DISPOSE_ON_CLOSE
        );

        setLayout(null);

        getContentPane().setBackground(
            new Color(241, 245, 249)
        );



        JPanel panelHeader = new JPanel();

        panelHeader.setBackground(
            new Color(202, 138, 4)
        );

        panelHeader.setBounds(0, 0, 850, 70);

        panelHeader.setLayout(null);

        add(panelHeader);



        JLabel lblTitulo = new JLabel(
            "Productos con Bajo Stock"
        );

        lblTitulo.setFont(
            new Font("Arial", Font.BOLD, 24)
        );

        lblTitulo.setForeground(Color.WHITE);

        lblTitulo.setBounds(30, 18, 500, 35);

        panelHeader.add(lblTitulo);



        lblAviso = new JLabel(
            "Estos productos requieren reabastecimiento"
        );

        lblAviso.setFont(
            new Font("Arial", Font.BOLD, 14)
        );

        lblAviso.setForeground(
            new Color(202, 138, 4)
        );

        lblAviso.setBounds(20, 85, 600, 25);

        add(lblAviso);



        JScrollPane scroll = new JScrollPane();

        scroll.setBounds(20, 118, 800, 360);

        add(scroll);



        tablaProductos = new JTable() {

            private static final long
                serialVersionUID = 1L;

            @Override
            public boolean isCellEditable(
                int row,
                int column
            ) {
                return false;
            }
        };

        tablaProductos.setRowHeight(32);

        tablaProductos.setFont(
            new Font("Arial", Font.PLAIN, 14)
        );

        tablaProductos.getTableHeader().setFont(
            new Font("Arial", Font.BOLD, 14)
        );

        tablaProductos.getTableHeader()
            .setBackground(
                new Color(254, 243, 199)
            );

        scroll.setViewportView(tablaProductos);
    }

    public JTable getTablaProductos() {
        return tablaProductos;
    }

    public JLabel getLblAviso() {
        return lblAviso;
    }
}